# Citations and data-source notes

## Primary theoretical/statistical sources

- Hahn, M., Degen, J., & Futrell, R. (2021). *Modeling word and morpheme order in natural language as an efficient tradeoff of memory and surprisal*. Psychological Review (preprint supplied in this project).
- Koplenig, A., Meyer, P., Wolfer, S., & Müller-Spitzer, C. (2017). *The statistical trade-off between word order and word structure – Large-scale evidence for the principle of least effort*. PLOS ONE 12(3): e0173614.
- Pratap, V. et al. (2020). *MLS: A Large-Scale Multilingual Dataset for Speech Research*. Interspeech.
- Lee, B. et al. (2024). *Speech-MASSIVE: A Multilingual Speech Dataset for SLU and Beyond*. Interspeech 2024.
- FitzGerald, J. et al. (2022). *MASSIVE: A 1M-Example Multilingual Natural Language Understanding Dataset with 51 Typologically-Diverse Languages*.
- Asonitis, A. et al. (2026). *WorldSpeech: A Multilingual Speech Corpus from Around the World*.

## Data access

Common Voice is accessed only through Mozilla Data Collective. The dataset provider currently requires authentication and acceptance of dataset-specific terms. No attempt is made to circumvent these requirements.

MLS is accessed through the streamable Hugging Face restructuring of the OpenSLR MLS corpus.

Speech-MASSIVE is accessed through its official Hugging Face dataset mirror.

MASSIVE is accessed through the AmazonScience Hugging Face dataset.

WorldSpeech is optional and disabled by default.
