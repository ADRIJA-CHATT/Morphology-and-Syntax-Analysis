# Information Locality Relative to Time — 20-Language Research Bundle

This bundle is a self-contained Python project for estimating **character-level information locality** and testing the proposed morphology/syntax/speech-realization hypothesis across:

English, German, Dutch, Swedish, French, Spanish, Italian, Portuguese, Russian, Polish, Czech, Turkish, Finnish, Hungarian, Indonesian, Vietnamese, Hindi, Mandarin Chinese, Japanese, and Korean.

## Research target

The primary dependent variable is a **time-normalized information-locality decay parameter**.

We represent each normalized Unicode character as one sequential token and estimate

\[
I_t = I(C_t:C_0\mid C_1,\ldots,C_{t-1})
\]

at character lag \(t\). This is the conditional mutual information quantity used by Hahn, Degen & Futrell for information locality. They define \(I_t\) as predictive information supplied by the element \(t\) positions in the past, conditional on the intervening elements, and show the equivalent estimator

\[
I_t=S_t-S_{t+1},
\]

where \(S_t\) is the average surprisal of an order-\(t\) Markov predictor. The paper uses neural LSTMs for this estimation and evaluates surprisal on held-out data. See the supplied paper, especially pp. 16–17 and the definitions around Eq. (6). The same paper emphasizes that conditional mutual information, rather than unconditional mutual information, is the theoretically relevant quantity for its memory bound.

For the present project, character lags are converted to seconds using observed speech duration / character count:

\[
\Delta\tau_t = t\,\overline{\delta_c},
\qquad
\overline{\delta_c}
=
\frac{\sum_j d_j}{\sum_j n_j},
\]

with \(d_j\) the duration of speech segment \(j\) and \(n_j\) its normalized character count.

The primary decay model is

\[
I(\Delta\tau)=A\exp(-\lambda\Delta\tau)+\epsilon.
\]

The main dependent variable is `locality_lambda_per_s`. Larger \(\lambda\) means faster decay in time, hence stronger temporal locality.

A secondary Hilberg-style power-law model is also fit:

\[
I_t \propto t^{-\alpha}-(t+1)^{-\alpha}.
\]

The supplied paper notes the connection between the decay of \(I_t\) and the Relaxed Hilberg Conjecture. The bundle reports this as `hilberg_alpha` rather than silently replacing the primary exponential outcome.

The bundle also computes the memory-cost quantity

\[
R_T=\sum_{t=1}^{T} tI_t,
\]

which follows directly from the Information Locality Bound theorem and is useful as a sensitivity analysis.

## Inputs

The principal language-level predictors are:

- `syllable_rate_sps`: syllables per second, estimated from observed speech duration and an automatically selected syllable-count heuristic.
- `word_rate_wps`: words per second.
- `mean_word_length_chars`: mean characters per whitespace-delimited word.
- `morphology_index`: normalized word-structure redundancy relative to word-order redundancy.
- `word_structure_redundancy`: \(D_\text{structure}=H_\text{structure}-H_\text{original}\) using the bundle's corpus estimator.
- `word_order_redundancy`: \(D_\text{order}=H_\text{order}-H_\text{original}\).
- `char_entropy_rate_bits`: character entropy-rate estimate.
- `lexical_ttr`: type-token ratio on a controlled text sample.
- `mean_utterance_duration_s`.
- `mean_chars_per_utterance`.
- `speech_text_coverage`: amount of speech data supporting the time calibration.
- script indicators and corpus-source indicators as optional regularized controls.

The morphology index is inspired by Koplenig et al.'s information-theoretic decomposition of word order and word-internal structure. Their exact estimator uses a longest-match entropy-rate estimator and compares the original string with word-order randomized and word-structure-masked strings. The present implementation retains that conceptual decomposition but uses a scalable held-out character language-model estimator. It is therefore an **operational proxy**, not a claim to reproduce their exact numerical \(D_\text{order}\) and \(D_\text{structure}\).

## Data sources

### Mozilla Common Voice Scripted Speech 26.0

The current Mozilla Data Collective lists Common Voice Scripted Speech 26.0 as CC0 and provides language-specific datasets. The bundle discovers and downloads the required language datasets through the official Mozilla Data Collective Python SDK.

Important: Mozilla now requires API authentication and agreement to each dataset's terms before programmatic access. This is a source-side access requirement and cannot legitimately be bypassed. The bundle therefore removes all *manual file downloading*, but you still need an MDC API key and must accept the relevant dataset terms once.

Set:

```bash
MDC_API_KEY=YOUR_KEY
```

The bundle automatically locates the requested v26.0 Common Voice dataset for each language from the public Common Voice organization listing / MDC API.

### Multilingual LibriSpeech

For the eight MLS languages (English, German, Dutch, Spanish, French, Italian, Portuguese, Polish), the bundle uses the streamable Hugging Face copy of MLS, avoiding the need to manually fetch the enormous OpenSLR tar archives. Audio is streamed and only the requested analysis statistics are materialized.

### Speech-MASSIVE

Speech-MASSIVE is loaded from Hugging Face. It contains speech for 12 languages, including German, Spanish, French, Hungarian, Korean, Dutch, Polish, European Portuguese, Russian, Turkish and Vietnamese, with train/dev/test variants depending on language.

### MASSIVE

MASSIVE 1.1 provides >1M text utterances in 51 languages. It is used primarily as a text source because MASSIVE itself is text rather than a speech-duration resource.

### Optional WorldSpeech

WorldSpeech is supported as an additional speech source. It contains transcript + duration metadata and can therefore be used for large-scale time calibration without decoding audio. It is disabled by default because its CC-BY-NC licensing and heterogeneous source licenses should be considered carefully for the intended research use.

## Why character tokens?

For the initial experiment, the sequence is deliberately defined at the orthographic character level. This avoids cross-language ambiguity about what constitutes a word or morpheme and makes the locality unit exactly the unit specified in the project request.

The code normalizes text with Unicode NFC, turns punctuation/control characters into spaces, preserves letters/numbers/combining marks, and collapses whitespace. It then appends an explicit sentence boundary. No cross-language transliteration is performed.

For Chinese, Japanese, and Korean, the characters remain their native Unicode symbols. This is important: the pipeline does not silently romanize those scripts.

## Language-model estimator

The production estimator is a small character LSTM implemented in PyTorch.

For each language:

1. Build a deterministic, stratified text sample.
2. Split text into train and held-out streams.
3. Train a character LM on the training stream.
4. Evaluate held-out surprisal under finite context windows \(t=0,1,\ldots,T\).
5. Compute \(I_t=S_t-S_{t+1}\).
6. Convert character lag to seconds using speech-derived seconds-per-character.
7. Fit exponential and power-law decay models.

This mirrors the logic of Hahn, Degen & Futrell: fit predictors for \(S_t\) and \(S_{t+1}\), then difference them to estimate conditional mutual information.

### Finite-data safeguards

The supplied paper explicitly warns that estimates of \(I_t\) become less trustworthy for large \(t\), especially with less data. The bundle therefore:

- defaults to \(T=32\) for a practical full run;
- requires a minimum held-out character count before estimating large lags;
- reports bootstrap confidence intervals for the fitted decay rate;
- stores the complete \(I_t\) curve so the user can inspect where estimation becomes unstable;
- permits increasing \(T\) on a sufficiently large corpus.

## Statistical model

The principal language-level regression is ridge regression:

\[
y_\ell = \beta_0+\sum_k x_{\ell k}\beta_k+\epsilon_\ell,
\]

where

\[
y_\ell=\lambda_\ell.
\]

The predictors are standardized. Ridge regularization is tuned by leave-one-language-out cross-validation. The default specification also includes the theoretically motivated interactions morphology × speech rate, word length × speech rate, and morphology × word length. A Bayesian Ridge and Elastic-Net sensitivity model are also fitted.

The bundle also supports an optional observation-level regression if you elect to treat source-specific locality estimates as independent observations. The default analysis does **not** use source duplicates as independent replicates of a language-level linguistic parameter.

Because there are only 20 requested languages, this is an exploratory statistical model, not a causal identification strategy. Regularization protects coefficient magnitudes but cannot create independent degrees of freedom. The README deliberately keeps this limitation explicit.

## Folder structure

```text
information_locality_time_bundle/
├── README.md
├── requirements.txt
├── pyproject.toml
├── .env.example
├── config.yaml
├── run_pipeline.py
└── src/
    ├── __init__.py
    ├── config.py
    ├── normalization.py
    ├── downloaders.py
    ├── corpora.py
    ├── speech_features.py
    ├── entropy.py
    ├── morphology.py
    ├── locality.py
    ├── decay.py
    ├── regression.py
    ├── pipeline.py
    └── utils.py
```

## Installation

Recommended: Python 3.11 or 3.12.

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate

python -m pip install --upgrade pip
pip install -r requirements.txt
```

Create `.env` from `.env.example` and set `MDC_API_KEY`.

Optional Hugging Face authentication can be supplied with `HF_TOKEN`, although the public datasets supported here do not normally require it.

## Run

### Full automatic pipeline

```bash
python run_pipeline.py --mode full
```

### Faster pilot

```bash
python run_pipeline.py --mode pilot
```

The pilot mode intentionally samples fewer characters and speech utterances. It is useful for validating that all dependencies, data access, and modeling steps work before launching a multi-hundred-GB data job.

### CPU/HPC execution

The bundle is designed to work on ordinary CPUs and GPUs. Set:

```bash
python run_pipeline.py --mode full --device cuda
```

or:

```bash
python run_pipeline.py --mode full --device cpu
```

On a cluster, put the command in your scheduler script. The code writes intermediate JSON/Parquet/CSV products after every major stage, so a failed later step does not require restarting data ingestion.

## Outputs

The pipeline writes:

```text
results/
├── language_features.csv
├── locality_curves.csv
├── decay_parameters.csv
├── regression_coefficients.csv
├── regression_predictions.csv
├── feature_matrix.csv
├── source_coverage.csv
├── run_metadata.json
└── plots/
    ├── locality_curves.png
    ├── decay_by_language.png
    ├── morphology_vs_locality.png
    └── observed_vs_predicted.png
```

## Recommended interpretation

The strongest direct hypothesis test is:

\[
\lambda =
\beta_0
+\beta_1(\text{morphology})
+\beta_2(\text{speech rate})
+\beta_3(\text{word length})
+\beta_4(\text{controls})
+\epsilon.
\]

The theoretically interesting interaction is:

\[
\text{morphology}\times\text{speech rate}
\]

because the project hypothesis concerns information packaging jointly with speech realization rather than treating morphology as an isolated typological label.

The model therefore includes that interaction by default.

## Important methodological distinction

The locality estimator is **text-based**, while the conversion of character distance to physical time is speech-based. This is intentional and should be reported explicitly:

- text determines predictive information structure;
- speech determines the time scale.

This avoids claiming that character sequences themselves contain timing information.

The interpretation is therefore:

> how quickly predictive information decays per unit of time, when text structure is calibrated to observed speech realization.

This is closer to the stated research question than simply regressing word counts on morphology.

## Citations

Koplenig et al. (2017), *The statistical trade-off between word order and word structure — Large-scale evidence for the principle of least effort*, PLOS ONE 12(3): e0173614.

Hahn, Degen & Futrell (2021), *Modeling word and morpheme order in natural language as an efficient tradeoff of memory and surprisal*.

MLS: Pratap et al. (2020), *MLS: A Large-Scale Multilingual Dataset for Speech Research*.

Speech-MASSIVE: Lee et al. (2024), *Speech-MASSIVE: A Multilingual Speech Dataset for SLU and Beyond*.

MASSIVE: FitzGerald et al. (2022), *MASSIVE: A 1M-Example Multilingual Natural Language Understanding Dataset with 51 Typologically-Diverse Languages*.

WorldSpeech: Asonitis et al. (2026), *WorldSpeech: A Multilingual Speech Corpus from Around the World*.

## Reproducibility

Every sampling decision, random seed, source, model hyperparameter, and fitted decay curve is written to `results/run_metadata.json`.

The bundle never overwrites an existing run unless `--overwrite` is given.
