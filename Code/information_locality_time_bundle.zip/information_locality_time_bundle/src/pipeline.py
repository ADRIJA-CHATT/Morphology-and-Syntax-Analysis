from __future__ import annotations

from pathlib import Path
import platform
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from config import load_settings
from corpora import (
    load_common_voice_samples,
    load_mls_samples,
    load_massive_text_samples,
    load_speech_massive_samples,
    load_worldspeech_samples,
)
from normalization import sentence_stream
from morphology import all_text_features
from speech_features import aggregate_speech_features
from locality import estimate_information_locality
from decay import fit_decay, bootstrap_lambda, memory_cost
from regression import fit_models
from utils import choose_device, write_json


LANGUAGE_FAMILY = {
    "English": "Germanic", "German": "Germanic", "Dutch": "Germanic", "Swedish": "Germanic",
    "French": "Romance", "Spanish": "Romance", "Italian": "Romance", "Portuguese": "Romance",
    "Russian": "Slavic", "Polish": "Slavic", "Czech": "Slavic",
    "Turkish": "Turkic", "Finnish": "Uralic", "Hungarian": "Uralic",
    "Indonesian": "Austronesian", "Vietnamese": "Austroasiatic",
    "Hindi": "Indo-Aryan", "Mandarin Chinese": "Sinitic",
    "Japanese": "Japonic", "Korean": "Koreanic",
}

SCRIPT = {
    "English": "Latin", "German": "Latin", "Dutch": "Latin", "Swedish": "Latin",
    "French": "Latin", "Spanish": "Latin", "Italian": "Latin", "Portuguese": "Latin",
    "Russian": "Cyrillic", "Polish": "Latin", "Czech": "Latin",
    "Turkish": "Latin", "Finnish": "Latin", "Hungarian": "Latin",
    "Indonesian": "Latin", "Vietnamese": "Latin", "Hindi": "Devanagari",
    "Mandarin Chinese": "Han", "Japanese": "Mixed-CJK", "Korean": "Hangul",
}


def run(config_path: Path, mode: str, device: str = "auto", overwrite: bool = False):
    settings = load_settings(config_path, mode)
    device = choose_device(device)
    data_root = settings.data_root
    out_root = settings.results_root
    out_root.mkdir(parents=True, exist_ok=True)

    metadata_path = out_root / "run_metadata.json"
    if metadata_path.exists() and not overwrite:
        raise FileExistsError(f"{metadata_path} already exists. Use --overwrite for a new run.")

    start = time.time()
    sampling = settings.sampling()
    seed = int(sampling["seed"])
    device_used = device

    feature_rows = []
    curve_rows = []
    coverage_rows = []

    for language, lang_code in settings.languages.items():
        print(f"\n=== {language} ({lang_code}) ===")

        text_sources = []
        speech_sources = []

        if settings.raw["data"].get("use_common_voice", True):
            try:
                t, s = load_common_voice_samples(
                    language, lang_code, data_root,
                    settings.raw["data"]["common_voice_version"],
                    sampling["max_text_chars_per_language_source"] // 100,
                    sampling["max_speech_segments_per_language_source"],
                    seed,
                )
                text_sources += t
                speech_sources += s
            except Exception as exc:
                print(f"[Common Voice] skipped: {exc}")

        if settings.raw["data"].get("use_mls", True):
            try:
                t, s = load_mls_samples(
                    language,
                    sampling["max_text_chars_per_language_source"] // 100,
                    sampling["max_speech_segments_per_language_source"],
                    seed,
                )
                text_sources += t
                speech_sources += s
            except Exception as exc:
                print(f"[MLS] skipped: {exc}")

        if settings.raw["data"].get("use_speech_massive", True):
            try:
                t, s = load_speech_massive_samples(
                    language,
                    sampling["max_text_chars_per_language_source"] // 100,
                    sampling["max_speech_segments_per_language_source"],
                    seed,
                )
                text_sources += t
                speech_sources += s
            except Exception as exc:
                print(f"[Speech-MASSIVE] skipped: {exc}")

        if settings.raw["data"].get("use_massive", True):
            try:
                text_sources += load_massive_text_samples(
                    language,
                    sampling["max_text_chars_per_language_source"] // 100,
                    seed,
                )
            except Exception as exc:
                print(f"[MASSIVE] skipped: {exc}")

        if settings.raw["data"].get("use_worldspeech", False):
            try:
                t, s = load_worldspeech_samples(
                    language,
                    sampling["max_text_chars_per_language_source"] // 100,
                    sampling["max_speech_segments_per_language_source"],
                    seed,
                )
                text_sources += t
                speech_sources += s
            except Exception as exc:
                print(f"[WorldSpeech] skipped: {exc}")

        # Source-balanced text collection to keep one enormous source from dominating.
        texts_by_source = {}
        for u in text_sources:
            texts_by_source.setdefault(u.source, []).append(u.text)
        per_source_budget = sampling["max_text_chars_per_language_source"]

        pieces = []
        for source, arr in sorted(texts_by_source.items()):
            stream = sentence_stream(arr)
            pieces.append(stream[:per_source_budget])

        corpus_text = " ".join(pieces)
        if len(corpus_text) < 20000:
            print(f"[warning] only {len(corpus_text):,} usable characters for {language}")

        speech_feats = aggregate_speech_features(speech_sources, lang_code)
        morph_feats = all_text_features(corpus_text[: min(len(corpus_text), 2_000_000)], seed=seed)

        # Train text locality model on a deterministic subset.
        lp = settings.raw["locality"].copy()
        locality = estimate_information_locality(
            language=language,
            text=corpus_text,
            seconds_per_character=speech_feats["seconds_per_character"],
            max_lag=int(settings.raw["locality"]["max_lag_chars"]),
            params=lp,
            device=device_used,
            seed=seed,
        )

        decay = fit_decay(
            locality.lags,
            locality.information,
            locality.seconds_per_character,
            positive_floor=float(settings.raw["locality"]["min_positive_it"]),
        )
        decay.update(
            bootstrap_lambda(
                locality.lags,
                locality.information,
                locality.seconds_per_character,
                reps=int(settings.raw["locality"]["bootstrap_reps"]),
                seed=seed,
            )
        )
        decay["memory_cost_T"] = memory_cost(locality.lags, locality.information)

        # Save locality curve.
        for lag, s_val, i_val in zip(locality.lags, locality.surprisal[1:], locality.information):
            curve_rows.append({
                "language": language,
                "lang_code": lang_code,
                "lag_characters": lag,
                "lag_seconds": lag * locality.seconds_per_character,
                "S_t_or_S_tplus1": s_val,
                "I_t_bits": i_val,
            })

        row = {
            "language": language,
            "lang_code": lang_code,
            "language_family": LANGUAGE_FAMILY[language],
            "script": SCRIPT[language],
            **speech_feats,
            **morph_feats,
            **decay,
        }

        feature_rows.append(row)

        coverage_rows.append({
            "language": language,
            "text_characters": len(corpus_text),
            "n_text_sources": len(texts_by_source),
            "n_speech_segments": len(speech_sources),
            "total_speech_seconds": speech_feats.get("total_speech_seconds", 0.0),
        })

    features = pd.DataFrame(feature_rows)
    curves = pd.DataFrame(curve_rows)
    coverage = pd.DataFrame(coverage_rows)

    features.to_csv(out_root / "language_features.csv", index=False)
    curves.to_csv(out_root / "locality_curves.csv", index=False)
    coverage.to_csv(out_root / "source_coverage.csv", index=False)

    if len(features) >= 8:
        fit_models(
            features,
            out_root,
            include_interactions=bool(settings.raw["regression"].get("include_interactions", True)),
        )

    _plot_results(features, curves, out_root)

    write_json(
        metadata_path,
        {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "elapsed_seconds": time.time() - start,
            "python": platform.python_version(),
            "platform": platform.platform(),
            "device": device_used,
            "mode": mode,
            "languages": list(settings.languages.keys()),
            "config": settings.raw,
        },
    )


def _plot_results(features: pd.DataFrame, curves: pd.DataFrame, out_root: Path):
    p = out_root / "plots"
    p.mkdir(parents=True, exist_ok=True)

    if not curves.empty:
        plt.figure(figsize=(10, 7))
        for lang, g in curves.groupby("language"):
            plt.plot(g["lag_seconds"], g["I_t_bits"], alpha=0.55, label=lang)
        plt.xlabel("Lag (seconds)")
        plt.ylabel("Estimated conditional mutual information (bits)")
        plt.title("Character-level information locality curves")
        plt.legend(fontsize=7, ncol=2)
        plt.tight_layout()
        plt.savefig(p / "locality_curves.png", dpi=200)
        plt.close()

    if not features.empty:
        s = features.sort_values("locality_lambda_per_s", ascending=False)
        plt.figure(figsize=(10, 7))
        plt.barh(s["language"], s["locality_lambda_per_s"])
        plt.xlabel("Decay rate λ (1/s)")
        plt.title("Estimated temporal information-locality decay")
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig(p / "decay_by_language.png", dpi=200)
        plt.close()

        plt.figure(figsize=(8, 6))
        plt.scatter(features["morphology_index"], features["locality_lambda_per_s"])
        plt.xlabel("Morphology index")
        plt.ylabel("Temporal locality decay λ (1/s)")
        plt.title("Morphology vs. information-locality decay")
        plt.tight_layout()
        plt.savefig(p / "morphology_vs_locality.png", dpi=200)
        plt.close()

        pred_path = out_root / "regression_predictions.csv"
        if pred_path.exists():
            pred = pd.read_csv(pred_path)
            plt.figure(figsize=(7, 7))
            plt.scatter(pred["observed_lambda"], pred["predicted_lambda"])
            lo = min(pred["observed_lambda"].min(), pred["predicted_lambda"].min())
            hi = max(pred["observed_lambda"].max(), pred["predicted_lambda"].max())
            plt.plot([lo, hi], [lo, hi], linestyle="--")
            plt.xlabel("Observed λ")
            plt.ylabel("LOO-CV predicted λ")
            plt.title("Observed vs. predicted locality decay")
            plt.tight_layout()
            plt.savefig(p / "observed_vs_predicted.png", dpi=200)
            plt.close()
