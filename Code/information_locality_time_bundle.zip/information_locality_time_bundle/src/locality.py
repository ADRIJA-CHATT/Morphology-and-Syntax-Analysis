from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
import numpy as np
import torch
from torch import nn
from tqdm import tqdm

from utils import stable_seed


@dataclass
class LocalityResult:
    language: str
    lags: list[int]
    surprisal: list[float]
    information: list[float]
    seconds_per_character: float


class CharLM(nn.Module):
    def __init__(self, vocab_size: int, embedding_dim: int, hidden_dim: int, layers: int, dropout: float):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, embedding_dim)
        self.rnn = nn.LSTM(
            embedding_dim,
            hidden_dim,
            num_layers=layers,
            batch_first=True,
            dropout=dropout if layers > 1 else 0.0,
        )
        self.out = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x, hidden=None):
        z = self.emb(x)
        z, hidden = self.rnn(z, hidden)
        return self.out(z), hidden


def make_vocab(text: str):
    chars = sorted(set(text))
    # reserve PAD and EOS
    vocab = ["<pad>", "<eos>"] + chars
    stoi = {c: i for i, c in enumerate(vocab)}
    itos = {i: c for c, i in stoi.items()}
    return vocab, stoi, itos


def to_ids(text: str, stoi: dict[str, int]) -> np.ndarray:
    eos = stoi["<eos>"]
    return np.asarray([stoi.get(c, eos) for c in text], dtype=np.int64)


def build_examples(ids: np.ndarray, seq_len: int, max_examples: int) -> tuple[np.ndarray, np.ndarray]:
    if len(ids) < seq_len + 2:
        raise ValueError("Not enough training characters.")
    n = min(max_examples, max(1, len(ids) // seq_len))
    starts = np.linspace(0, len(ids) - seq_len - 1, n, dtype=int)
    x = np.stack([ids[s:s+seq_len] for s in starts])
    y = np.stack([ids[s+1:s+seq_len+1] for s in starts])
    return x, y


def train_char_lm(
    train_text: str,
    valid_text: str,
    max_lag: int,
    device: str,
    params: dict,
    language: str,
    seed: int,
):
    torch.manual_seed(stable_seed(language, "torch", base=seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(stable_seed(language, "cuda", base=seed))

    vocab, stoi, itos = make_vocab(train_text)
    train_ids = to_ids(train_text, stoi)
    valid_ids = to_ids(valid_text, stoi)

    model = CharLM(
        len(vocab),
        params["embedding_dim"],
        params["hidden_dim"],
        params["num_layers"],
        params["dropout"],
    ).to(device)

    opt = torch.optim.AdamW(
        model.parameters(),
        lr=params["learning_rate"],
        weight_decay=params["weight_decay"],
    )
    loss_fn = nn.CrossEntropyLoss()
    model.train()

    x_np, y_np = build_examples(
        train_ids,
        params["seq_len"],
        max_examples=max(2000, min(50000, len(train_ids) // max(1, params["seq_len"]))),
    )
    order = np.arange(len(x_np))

    for epoch in range(params["epochs"]):
        np.random.default_rng(stable_seed(language, "epoch", epoch, base=seed)).shuffle(order)
        for start in range(0, len(order), params["batch_size"]):
            idx = order[start:start + params["batch_size"]]
            x = torch.as_tensor(x_np[idx], dtype=torch.long, device=device)
            y = torch.as_tensor(y_np[idx], dtype=torch.long, device=device)
            opt.zero_grad(set_to_none=True)
            logits, _ = model(x)
            loss = loss_fn(logits.reshape(-1, logits.shape[-1]), y.reshape(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

    return model, vocab, stoi, valid_ids


@torch.no_grad()
def evaluate_windowed_surprisal(
    model: nn.Module,
    valid_ids: np.ndarray,
    max_lag: int,
    device: str,
    batch_size: int,
) -> list[float]:
    """
    Estimate S_t with a model whose effective history is truncated to t characters.

    To keep the computation tractable, evaluation positions are sampled across the
    held-out stream. For each position and lag t, the model sees only the preceding
    t characters. S_0 is the unigram-like no-context model.

    This follows the paper's operational relationship I_t = S_t - S_{t+1}.
    """
    if len(valid_ids) < max_lag + 10:
        raise ValueError("Held-out text is too short for requested max_lag.")

    model.eval()
    positions = np.arange(max_lag, len(valid_ids) - 1)
    max_positions = min(len(positions), 200000)
    if len(positions) > max_positions:
        positions = np.linspace(positions[0], positions[-1], max_positions, dtype=int)

    surprisals = []
    for lag in range(max_lag + 1):
        losses = []
        for start in range(0, len(positions), batch_size):
            ps = positions[start:start + batch_size]
            if lag == 0:
                ctx = np.empty((len(ps), 0), dtype=np.int64)
                targets = valid_ids[ps]
                # Predict from an empty context by using the first output after a PAD token.
                x = torch.full((len(ps), 1), 0, dtype=torch.long, device=device)
                logits, _ = model(x)
                lp = torch.log_softmax(logits[:, -1, :], dim=-1)
                vals = -lp[torch.arange(len(ps), device=device), torch.as_tensor(targets, device=device)]
                losses.extend(vals.detach().cpu().numpy().tolist())
                continue

            seqs = np.stack([valid_ids[p-lag:p] for p in ps])
            targets = valid_ids[ps]
            x = torch.as_tensor(seqs, dtype=torch.long, device=device)
            logits, _ = model(x)
            lp = torch.log_softmax(logits[:, -1, :], dim=-1)
            vals = -lp[torch.arange(len(ps), device=device), torch.as_tensor(targets, device=device)]
            losses.extend(vals.detach().cpu().numpy().tolist())
        surprisals.append(float(np.mean(losses) / math.log(2)))
    return surprisals


def estimate_information_locality(
    language: str,
    text: str,
    seconds_per_character: float,
    max_lag: int,
    params: dict,
    device: str,
    seed: int,
) -> LocalityResult:
    if len(text) < params["train_chars"] + params["valid_chars"] + max_lag + 10:
        # deterministic split for smaller pilot runs
        n_train = max(100_000, int(0.8 * len(text)))
    else:
        n_train = params["train_chars"]

    train_text = text[:n_train]
    valid_text = text[n_train:n_train + params["valid_chars"]]
    if len(valid_text) < max_lag + 100:
        valid_text = text[-min(params["valid_chars"], len(text) // 5):]

    seed_list = params.get("seeds", [seed])
    curves = []
    for model_seed in seed_list:
        model, vocab, stoi, valid_ids = train_char_lm(
            train_text, valid_text, max_lag, device, params, language, int(model_seed)
        )
        S = evaluate_windowed_surprisal(
            model, valid_ids, max_lag=max_lag, device=device, batch_size=params["batch_size"]
        )
        curves.append(np.asarray(S, dtype=float))
    S_mean = np.mean(np.stack(curves, axis=0), axis=0)
    I = [max(0.0, float(S_mean[t] - S_mean[t + 1])) for t in range(max_lag)]
    return LocalityResult(
        language=language,
        lags=list(range(1, max_lag + 1)),
        surprisal=S_mean.tolist(),
        information=I,
        seconds_per_character=float(seconds_per_character),
    )
