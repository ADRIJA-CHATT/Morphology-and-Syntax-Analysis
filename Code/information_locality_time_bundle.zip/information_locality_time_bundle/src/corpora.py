from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Any
import csv
import tarfile
import gzip
import json
import re
import numpy as np

try:
    from mutagen import File as MutagenFile
except Exception:
    MutagenFile = None
import pandas as pd

from downloaders import download_common_voice, iter_hf
from normalization import normalize_text
from utils import reservoir_append, stable_seed


LANG_TO_CV = {
    "English": "en",
    "German": "de",
    "Dutch": "nl",
    "Swedish": "sv",
    "French": "fr",
    "Spanish": "es",
    "Italian": "it",
    "Portuguese": "pt",
    "Russian": "ru",
    "Polish": "pl",
    "Czech": "cs",
    "Turkish": "tr",
    "Finnish": "fi",
    "Hungarian": "hu",
    "Indonesian": "id",
    "Vietnamese": "vi",
    "Hindi": "hi",
    "Mandarin Chinese": "zh",
    "Japanese": "ja",
    "Korean": "ko",
}


@dataclass
class Utterance:
    language: str
    text: str
    duration_s: float | None
    source: str
    speaker: str | None = None


def load_common_voice_samples(
    language: str,
    locale: str,
    data_root: Path,
    version: str,
    max_texts: int,
    max_speech: int,
    seed: int,
) -> tuple[list[Utterance], list[Utterance]]:
    root = download_common_voice(language, locale, data_root / "common_voice", version)
    candidates = list(root.rglob("*.tsv"))
    if not candidates:
        raise FileNotFoundError(f"No TSV metadata found under {root}")

    preferred = [p for p in candidates if p.name in {"validated.tsv", "train.tsv"}]
    tsv = preferred[0] if preferred else candidates[0]

    texts: list[Utterance] = []
    speech: list[Utterance] = []
    rng = np.random.default_rng(stable_seed(language, "cv", base=seed))
    seen_text = seen_speech = 0

    with tsv.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            text = normalize_text(row.get("sentence", ""))
            if not text:
                continue
            # Common Voice v26 TSVs normally contain clip + sentence; duration may or may
            # not be present depending on the packaging route.
            duration = _safe_float(row.get("duration"))
            if duration is None:
                duration = _common_voice_duration(root, row.get("path", ""))
            u = Utterance(language, text, duration, "common_voice", row.get("client_id"))
            seen_text = reservoir_append(texts, u, seen_text, max_texts, rng)
            if u.duration_s and u.duration_s > 0:
                seen_speech = reservoir_append(speech, u, seen_speech, max_speech, rng)
    return texts, speech


def load_mls_samples(
    language: str,
    max_texts: int,
    max_speech: int,
    seed: int,
) -> tuple[list[Utterance], list[Utterance]]:
    config = {
        "English": "english", "German": "german", "Dutch": "dutch",
        "French": "french", "Spanish": "spanish", "Italian": "italian",
        "Portuguese": "portuguese", "Polish": "polish",
    }.get(language)
    if not config:
        return [], []

    ds = iter_hf("facebook/multilingual_librispeech", config, "train", streaming=True)
    texts: list[Utterance] = []
    speech: list[Utterance] = []
    rng = np.random.default_rng(stable_seed(language, "mls", base=seed))
    seen_text = seen_speech = 0

    for row in ds:
        text = normalize_text(row.get("transcript") or row.get("text") or "")
        if len(text) < 2:
            continue
        begin = row.get("begin_time")
        end = row.get("end_time")
        duration = None
        if begin is not None and end is not None:
            duration = max(0.0, float(end) - float(begin))
        u = Utterance(language, text, duration, "mls", str(row.get("speaker_id", "")))
        seen_text = reservoir_append(texts, u, seen_text, max_texts, rng)
        if duration is not None and duration > 0:
            seen_speech = reservoir_append(speech, u, seen_speech, max_speech, rng)
        if seen_text >= max_texts and seen_speech >= max_speech:
            break
    return texts, speech


def load_massive_text_samples(
    language: str,
    max_texts: int,
    seed: int,
) -> list[Utterance]:
    massive_code = {
        "English": "en-US", "German": "de-DE", "Spanish": "es-ES",
        "French": "fr-FR", "Finnish": "fi-FI", "Hungarian": "hu-HU",
        "Indonesian": "id-ID", "Italian": "it-IT", "Japanese": "ja-JP",
        "Korean": "ko-KR", "Dutch": "nl-NL", "Polish": "pl-PL",
        "Portuguese": "pt-PT", "Russian": "ru-RU", "Swedish": "sv-SE",
        "Turkish": "tr-TR", "Vietnamese": "vi-VN", "Chinese": "zh-CN",
        "Hindi": "hi-IN", "Czech": None,
    }
    config = massive_code.get(language)
    if not config:
        return []

    ds = iter_hf("AmazonScience/massive", config, "train", streaming=True)
    out: list[Utterance] = []
    rng = np.random.default_rng(stable_seed(language, "massive", base=seed))
    seen = 0
    for row in ds:
        text = normalize_text(row.get("text") or row.get("utt") or "")
        if len(text) < 2:
            continue
        u = Utterance(language, text, None, "massive")
        seen = reservoir_append(out, u, seen, max_texts, rng)
        if seen >= max_texts * 2 and len(out) >= max_texts:
            break
    return out


SPEECH_MASSIVE = {
    "German": "de-DE", "Spanish": "es-ES", "French": "fr-FR",
    "Hungarian": "hu-HU", "Korean": "ko-KR", "Dutch": "nl-NL",
    "Polish": "pl-PL", "Portuguese": "pt-PT", "Russian": "ru-RU",
    "Turkish": "tr-TR", "Vietnamese": "vi-VN",
}


def load_speech_massive_samples(
    language: str,
    max_texts: int,
    max_speech: int,
    seed: int,
) -> tuple[list[Utterance], list[Utterance]]:
    config = SPEECH_MASSIVE.get(language)
    if not config:
        return [], []
    # Full train exists only for French/German; validation is available for all supported languages.
    split = "train" if language in {"French", "German"} else "validation"
    ds = iter_hf("FBK-MT/Speech-MASSIVE", config, split, streaming=True)
    texts: list[Utterance] = []
    speech: list[Utterance] = []
    rng = np.random.default_rng(stable_seed(language, "speech_massive", base=seed))
    seen_text = seen_speech = 0

    for row in ds:
        text = normalize_text(row.get("transcription") or row.get("text") or row.get("sentence") or "")
        duration = row.get("duration")
        if duration is None:
            audio = row.get("audio")
            arr = audio.get("array") if isinstance(audio, dict) else None
            sr = audio.get("sampling_rate") if isinstance(audio, dict) else None
            if arr is not None and sr:
                duration = len(arr) / float(sr)
        if len(text) < 2:
            continue
        u = Utterance(language, text, float(duration) if duration is not None else None, "speech_massive")
        seen_text = reservoir_append(texts, u, seen_text, max_texts, rng)
        if u.duration_s and u.duration_s > 0:
            seen_speech = reservoir_append(speech, u, seen_speech, max_speech, rng)
        if len(texts) >= max_texts and len(speech) >= max_speech:
            break
    return texts, speech


WORLDSPEECH_CONFIGS = {
    "English": "en_us", "German": "de_at", "Dutch": "nl_nl", "French": "fr_fr",
    "Spanish": "es_es", "Italian": "it_it", "Portuguese": "pt_pt",
    "Russian": "ru_ru", "Polish": "pl_pl", "Czech": "cs_cz",
    "Turkish": "tr_tr", "Finnish": "fi_fi", "Hungarian": "hu_hu",
    "Indonesian": "id_id", "Vietnamese": "vn_vi", "Hindi": "hi_in",
    "Mandarin Chinese": "zh_cn", "Japanese": "ja_jp", "Korean": "ko_kr",
}


def load_worldspeech_samples(language: str, max_texts: int, max_speech: int, seed: int):
    config = WORLDSPEECH_CONFIGS.get(language)
    if not config:
        return [], []
    ds = iter_hf("disco-eth/WorldSpeech", config, "train", streaming=True)
    texts, speech = [], []
    rng = np.random.default_rng(stable_seed(language, "worldspeech", base=seed))
    seen_t = seen_s = 0
    for row in ds:
        text = normalize_text(row.get("human_transcript") or "")
        dur = _safe_float(row.get("duration"))
        if len(text) < 2:
            continue
        u = Utterance(language, text, dur, "worldspeech")
        seen_t = reservoir_append(texts, u, seen_t, max_texts, rng)
        if dur is not None:
            seen_s = reservoir_append(speech, u, seen_s, max_speech, rng)
        if len(texts) >= max_texts and len(speech) >= max_speech:
            break
    return texts, speech



def _common_voice_duration(root: Path, rel_path: str) -> float | None:
    if not rel_path:
        return None
    candidate = root / rel_path
    if not candidate.exists():
        matches = list(root.rglob(Path(rel_path).name))
        candidate = matches[0] if matches else candidate
    if not candidate.exists():
        return None
    if MutagenFile is not None:
        try:
            audio = MutagenFile(candidate)
            if audio is not None and getattr(audio, "info", None) is not None:
                d = float(getattr(audio.info, "length", 0.0))
                if d > 0:
                    return d
        except Exception:
            pass
    try:
        import soundfile as sf
        return float(sf.info(str(candidate)).duration)
    except Exception:
        return None

def _safe_float(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None
