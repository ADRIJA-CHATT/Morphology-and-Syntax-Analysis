from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, PolynomialFeatures
from sklearn.impute import SimpleImputer
from sklearn.linear_model import RidgeCV, BayesianRidge, ElasticNetCV
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error


NUMERIC = [
    "syllable_rate_sps",
    "word_rate_wps",
    "mean_word_length_chars",
    "morphology_index",
    "word_structure_redundancy",
    "word_order_redundancy",
    "char_entropy_rate_bits",
    "lexical_ttr",
    "mean_duration_s",
    "speech_char_rate_cps",
    "n_chars",
    "morphology_x_speech_rate",
    "word_length_x_speech_rate",
    "morphology_x_word_length",
]
CATEGORICAL = ["language_family", "script"]


def _add_interactions(df: pd.DataFrame, include_interactions: bool = True) -> pd.DataFrame:
    out = df.copy()
    if include_interactions:
        out["morphology_x_speech_rate"] = out["morphology_index"] * out["syllable_rate_sps"]
        out["word_length_x_speech_rate"] = out["mean_word_length_chars"] * out["syllable_rate_sps"]
        out["morphology_x_word_length"] = out["morphology_index"] * out["mean_word_length_chars"]
    return out


def prepare_features(df: pd.DataFrame, include_interactions: bool = True):
    df = _add_interactions(df, include_interactions)
    numeric = [c for c in NUMERIC if c in df.columns]
    categorical = [c for c in CATEGORICAL if c in df.columns]

    parts = [
        ("num", Pipeline([
            ("imp", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), numeric),
    ]

    if categorical:
        parts.append((
            "cat",
            Pipeline([
                ("imp", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore")),
            ]),
            categorical,
        ))

    transformer = ColumnTransformer(parts, remainder="drop")
    return transformer, numeric, categorical


def fit_models(df: pd.DataFrame, out_dir: Path, include_interactions: bool = True):
    df = df.copy()
    df = df[np.isfinite(df["locality_lambda_per_s"].astype(float))].copy()
    if len(df) < 8:
        raise RuntimeError("Regression needs at least 8 languages with finite locality estimates.")

    y = np.log(np.maximum(df["locality_lambda_per_s"].astype(float), 1e-8))
    X = _add_interactions(df.copy(), include_interactions)

    transformer, _, _ = prepare_features(X, include_interactions)

    alphas = np.logspace(-4, 4, 80)
    model = Pipeline([
        ("features", transformer),
        ("ridge", RidgeCV(alphas=alphas, cv=LeaveOneOut())),
    ])
    pred = cross_val_predict(model, X, y, cv=LeaveOneOut())
    model.fit(X, y)

    metrics = {
        "n_languages": int(len(df)),
        "cv_r2_log_lambda": float(r2_score(y, pred)),
        "cv_mae_log_lambda": float(mean_absolute_error(y, pred)),
        "cv_rmse_log_lambda": float(np.sqrt(mean_squared_error(y, pred))),
        "selected_alpha": float(model.named_steps["ridge"].alpha_),
    }

    predictions = pd.DataFrame({
        "language": df["language"].values,
        "observed_log_lambda": y.values,
        "predicted_log_lambda": pred,
        "observed_lambda": np.exp(y.values),
        "predicted_lambda": np.exp(pred),
        "cv_residual": y.values - pred,
    })

    try:
        names = model.named_steps["features"].get_feature_names_out()
        coefs = model.named_steps["ridge"].coef_
        coef_df = pd.DataFrame({"feature": names, "coefficient_log_lambda": coefs})
        coef_df["abs_coefficient"] = np.abs(coef_df["coefficient_log_lambda"])
        coef_df = coef_df.sort_values("abs_coefficient", ascending=False)
    except Exception:
        coef_df = pd.DataFrame()

    out_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([metrics]).to_csv(out_dir / "regression_metrics.csv", index=False)
    predictions.to_csv(out_dir / "regression_predictions.csv", index=False)
    coef_df.to_csv(out_dir / "regression_coefficients.csv", index=False)

    return metrics, predictions, coef_df
