from __future__ import annotations

from collections import Counter
import numpy as np

from entropy import morphology_redundancy


def lexical_features(text: str) -> dict:
    words = [w for w in text.split() if w]
    if not words:
        return {}
    types = len(set(words))
    return {
        "n_words": len(words),
        "n_word_types": types,
        "mean_word_length_chars": float(np.mean([len(w) for w in words])),
        "median_word_length_chars": float(np.median([len(w) for w in words])),
        "lexical_ttr": float(types / len(words)),
        "mean_chars_per_utterance": float(len(text)),
    }


def all_text_features(text: str, seed: int = 13) -> dict:
    out = lexical_features(text)
    out.update(morphology_redundancy(text, seed=seed))
    out["n_chars"] = len(text)
    return out
