from __future__ import annotations

from collections import Counter
import math
import unicodedata

VOWELS = {
    "en": set("aeiouy"), "de": set("aeiouyäöü"), "nl": set("aeiouy"),
    "sv": set("aeiouyåäö"), "fr": set("aeiouyàâäæéèêëîïôöœùûüÿ"),
    "es": set("aeiouáéíóúü"), "it": set("aeiouàèéìíîòóùú"),
    "pt": set("aeiouáàâãéêíóôõúü"), "ru": set("аеёиоуыэюя"),
    "pl": set("aąeęiouóy"), "cs": set("aáeéěiíoóuúůyý"),
    "tr": set("aeıioöuü"), "fi": set("aeiouyäö"), "hu": set("aáeéiíoóöőuúüű"),
    "id": set("aeiou"), "vi": set("aăâeêioôơuưy"),
    "hi": set("अआइईउऊएऐओऔ"), "zh": set(), "ja": set(), "ko": set(),
}


def syllable_count(text: str, lang_code: str) -> int:
    text = unicodedata.normalize("NFC", text.lower())
    if lang_code in {"zh", "ja"}:
        # Chinese/Japanese orthographies are mora/syllable-oriented enough for a
        # first-pass temporal proxy that one non-space CJK character = one beat.
        return max(1, sum(1 for c in text if unicodedata.category(c).startswith("L")))
    if lang_code == "ko":
        return max(1, sum(1 for c in text if "\uac00" <= c <= "\ud7a3"))
    if lang_code == "hi":
        # Approximate Hindi syllable nuclei by independent vowel signs / vowel letters.
        vowels = VOWELS["hi"]
        return max(1, sum(c in vowels for c in text))
    vowels = VOWELS.get(lang_code, set("aeiou"))
    count = 0
    prev = False
    for ch in text:
        is_v = ch in vowels
        if is_v and not prev:
            count += 1
        prev = is_v
    return max(1, count)


def aggregate_speech_features(utterances, lang_code: str) -> dict:
    durations = []
    chars = []
    words = []
    syllables = []
    char_per_sec = []
    word_per_sec = []
    syll_per_sec = []

    for u in utterances:
        if not u.duration_s:
            continue
        if u.duration_s <= 0:
            continue
        n_chars = max(1, len(u.text))
        n_words = max(1, len(u.text.split()))
        n_syll = syllable_count(u.text, lang_code)
        durations.append(u.duration_s)
        chars.append(n_chars)
        words.append(n_words)
        syllables.append(n_syll)
        char_per_sec.append(n_chars / u.duration_s)
        word_per_sec.append(n_words / u.duration_s)
        syll_per_sec.append(n_syll / u.duration_s)

    if not durations:
        return {
            "n_speech_segments": 0,
            "total_speech_seconds": 0.0,
            "mean_duration_s": float("nan"),
            "speech_char_rate_cps": float("nan"),
            "word_rate_wps": float("nan"),
            "syllable_rate_sps": float("nan"),
            "seconds_per_character": float("nan"),
        }

    # Ratio of totals is more stable than averaging per-utterance rates.
    return {
        "n_speech_segments": len(durations),
        "total_speech_seconds": float(sum(durations)),
        "mean_duration_s": float(sum(durations) / len(durations)),
        "speech_char_rate_cps": float(sum(chars) / sum(durations)),
        "word_rate_wps": float(sum(words) / sum(durations)),
        "syllable_rate_sps": float(sum(syllables) / sum(durations)),
        "seconds_per_character": float(sum(durations) / max(1, sum(chars))),
    }
