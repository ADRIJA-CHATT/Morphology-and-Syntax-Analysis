from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable
import requests
from dotenv import load_dotenv
from tqdm import tqdm

load_dotenv()


CV_ORG_URL = "https://mozilladatacollective.com/organization/cmfh0j9o10006ns07jq45h7xk"


def require_mdc_key() -> str:
    key = os.getenv("MDC_API_KEY", "").strip()
    if not key:
        raise RuntimeError(
            "Common Voice v26 requires Mozilla Data Collective authentication. "
            "Set MDC_API_KEY in .env after agreeing to the Common Voice dataset terms."
        )
    return key


def download_common_voice(language_name: str, locale: str, out_dir: Path, version: str = "26.0") -> Path:
    """
    Use the official MDC SDK. Dataset discovery is delegated to a small API lookup.

    The exact dataset ID can change between releases, so the code intentionally does
    not hard-code one opaque archive URL per language.
    """
    require_mdc_key()
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        from datacollective import download_dataset, get_dataset_details
    except ImportError as exc:
        raise RuntimeError("Install datacollective from requirements.txt.") from exc

    # Discover candidate datasets through the SDK's list/search functionality if available.
    # The official SDK is evolving, so we use a resilient fallback that queries the public
    # organization page for the v26 language slug when its convenience search is absent.
    dataset_id = _discover_cv_id(language_name, locale, version)
    target = out_dir / dataset_id
    if target.exists() and any(target.iterdir()):
        return target

    result = download_dataset(dataset_id, download_directory=str(out_dir))
    path = Path(str(result))
    if path.exists():
        return path
    return target


def _discover_cv_id(language_name: str, locale: str, version: str) -> str:
    try:
        from datacollective import search_datasets
        results = search_datasets(query=f"Common Voice Scripted Speech {version} {language_name}")
        for r in results:
            data = r if isinstance(r, dict) else getattr(r, "model_dump", lambda: {})()
            blob = str(data).lower()
            if version in blob and language_name.lower() in blob:
                if locale.lower() in blob or f" {locale.lower()} " in blob:
                    return str(data.get("id") or data.get("datasetId") or data.get("slug"))
    except Exception:
        pass

    # Public HTML fallback. This does not download data; it only recovers the published dataset ID.
    html = requests.get(CV_ORG_URL, timeout=60).text
    markers = [
        f"Common Voice Scripted Speech {version} - {language_name}",
        f"Common Voice Scripted Speech {version} – {language_name}",
    ]
    for marker in markers:
        pos = html.lower().find(marker.lower())
        if pos >= 0:
            window = html[max(0, pos - 2000): pos + 3000]
            # MDC IDs are 24-ish lowercase alpha-numeric strings.
            import re
            ids = re.findall(r"[a-z0-9]{20,30}", window)
            if ids:
                return ids[-1]

    raise RuntimeError(
        f"Could not discover MDC dataset ID for Common Voice {version} {language_name} ({locale}). "
        "Open the corresponding Common Voice dataset page once to verify that the language is present."
    )


def iter_hf(dataset_name: str, config: str | None, split: str, streaming: bool = True, **kwargs):
    from datasets import load_dataset
    if config:
        return load_dataset(dataset_name, config, split=split, streaming=streaming, **kwargs)
    return load_dataset(dataset_name, split=split, streaming=streaming, **kwargs)


def stream_download_http(url: str, destination: Path, chunk_size: int = 8 * 1024 * 1024) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        return destination
    with requests.get(url, stream=True, timeout=120) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", "0"))
        with destination.open("wb") as f, tqdm(
            total=total if total > 0 else None,
            unit="B",
            unit_scale=True,
            desc=destination.name,
        ) as pbar:
            for chunk in r.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    pbar.update(len(chunk))
    return destination
