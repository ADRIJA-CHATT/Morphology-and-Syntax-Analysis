from __future__ import annotations

from collections import Counter, defaultdict
from math import log2
from typing import Sequence
import numpy as np


def plugin_entropy(symbols: Sequence[str]) -> float:
    if not symbols:
        return float("nan")
    c = Counter(symbols)
    n = len(symbols)
    return -sum((v / n) * log2(v / n) for v in c.values())


def conditional_entropy_ngram(text: str, order: int = 5) -> float:
    """
    Held-out-free fast conditional-entropy proxy. For a research run, the pipeline
    uses the neural held-out entropy curve for locality; this estimator is intended
    for morphology/order perturbation scoring where exact entropy-rate replication
    is not required.
    """
    if len(text) <= order:
        return float("nan")
    ctx_counts = Counter(text[i-order:i] for i in range(order, len(text)))
    joint_counts = Counter((text[i-order:i], text[i]) for i in range(order, len(text)))
    total = len(text) - order
    h = 0.0
    for (ctx, nxt), nxy in joint_counts.items():
        pxy = nxy / total
        pyx = nxy / ctx_counts[ctx]
        h -= pxy * log2(pyx)
    return float(h)


def shuffled_words_text(text: str, rng: np.random.Generator) -> str:
    words = [w for w in text.split(" ") if w]
    if len(words) < 2:
        return text
    rng.shuffle(words)
    return " ".join(words)


def masked_structure_text(text: str, rng: np.random.Generator) -> str:
    words = [w for w in text.split(" ") if w]
    alphabet = sorted(set("".join(words)))
    if not alphabet:
        return text
    out = []
    for w in words:
        replacement = "".join(rng.choice(alphabet, size=len(w), replace=True))
        out.append(replacement)
    return " ".join(out)


def morphology_redundancy(text: str, seed: int = 13, n_reps: int = 2) -> dict:
    """
    Scalable analogue of Koplenig et al.'s perturbation idea:
      H_original  = entropy rate of the observed string
      H_order     = entropy after destroying word-order regularity
      H_structure = entropy after destroying intra-word regularity
      D_order     = H_order - H_original
      D_structure = H_structure - H_original

    This is deliberately labelled as a proxy because the original paper uses
    a longest-match entropy estimator rather than this n-gram entropy estimator.
    """
    rng = np.random.default_rng(seed)
    h0 = conditional_entropy_ngram(text)
    ho = []
    hs = []
    for _ in range(n_reps):
        ho.append(conditional_entropy_ngram(shuffled_words_text(text, rng)))
        hs.append(conditional_entropy_ngram(masked_structure_text(text, rng)))
    h_order = float(np.nanmean(ho))
    h_structure = float(np.nanmean(hs))
    d_order = max(0.0, h_order - h0)
    d_structure = max(0.0, h_structure - h0)
    denom = d_order + d_structure
    index = d_structure / denom if denom > 0 else float("nan")
    return {
        "char_entropy_rate_bits": h0,
        "H_order": h_order,
        "H_structure": h_structure,
        "word_order_redundancy": d_order,
        "word_structure_redundancy": d_structure,
        "morphology_index": index,
    }
