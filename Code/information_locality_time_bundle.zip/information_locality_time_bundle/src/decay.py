from __future__ import annotations

from dataclasses import asdict
import numpy as np
from scipy.optimize import curve_fit, least_squares


def exp_decay(t, A, lam):
    return A * np.exp(-lam * t)


def power_delta(t, A, alpha):
    # Corresponds to I_t proportional to t^-alpha - (t+1)^-alpha
    return A * (np.power(t, -alpha) - np.power(t + 1.0, -alpha))


def fit_decay(lags, information, seconds_per_character, positive_floor=1e-5):
    lags = np.asarray(lags, dtype=float)
    I = np.asarray(information, dtype=float)
    tau = lags * float(seconds_per_character)
    mask = np.isfinite(I) & np.isfinite(tau) & (I > positive_floor) & (tau > 0)
    t = tau[mask]
    y = I[mask]

    if len(y) < 5:
        return {
            "locality_lambda_per_s": np.nan,
            "locality_lambda_r2": np.nan,
            "hilberg_alpha": np.nan,
            "hilberg_r2": np.nan,
            "locality_amplitude": np.nan,
            "n_decay_points": int(len(y)),
        }

    p0 = [max(y[0], 1e-4), max(1.0 / max(np.median(t), 1e-3), 1e-3)]
    try:
        popt, _ = curve_fit(
            exp_decay, t, y, p0=p0,
            bounds=([1e-9, 1e-9], [np.inf, np.inf]),
            maxfev=20000,
        )
        pred = exp_decay(t, *popt)
        r2 = 1 - float(np.sum((y - pred) ** 2) / max(np.sum((y - y.mean()) ** 2), 1e-12))
        lam = float(popt[1])
        amp = float(popt[0])
    except Exception:
        lam = amp = r2 = np.nan

    mask2 = np.isfinite(I) & (I > positive_floor) & (lags > 0)
    tt = lags[mask2]
    yy = I[mask2]
    try:
        p2, _ = curve_fit(
            power_delta, tt, yy,
            p0=[max(yy[0], 1e-4), 0.5],
            bounds=([1e-9, 1e-6], [np.inf, 10.0]),
            maxfev=20000,
        )
        pred2 = power_delta(tt, *p2)
        r22 = 1 - float(np.sum((yy - pred2) ** 2) / max(np.sum((yy - yy.mean()) ** 2), 1e-12))
        alpha = float(p2[1])
    except Exception:
        alpha = r22 = np.nan

    return {
        "locality_lambda_per_s": lam,
        "locality_lambda_r2": r2,
        "hilberg_alpha": alpha,
        "hilberg_r2": r22,
        "locality_amplitude": amp,
        "n_decay_points": int(len(y)),
    }


def memory_cost(lags, information, T: int | None = None) -> float:
    lags = np.asarray(lags, dtype=float)
    I = np.asarray(information, dtype=float)
    if T is not None:
        mask = lags <= T
        lags = lags[mask]
        I = I[mask]
    return float(np.sum(lags * I))


def bootstrap_lambda(lags, information, seconds_per_character, reps=300, seed=13):
    rng = np.random.default_rng(seed)
    lags = np.asarray(lags)
    information = np.asarray(information)
    vals = []
    n = len(lags)
    if n < 5:
        return {"lambda_q025": np.nan, "lambda_q975": np.nan}
    for _ in range(reps):
        idx = rng.integers(0, n, n)
        fit = fit_decay(lags[idx], information[idx], seconds_per_character)
        if np.isfinite(fit["locality_lambda_per_s"]):
            vals.append(fit["locality_lambda_per_s"])
    if not vals:
        return {"lambda_q025": np.nan, "lambda_q975": np.nan}
    return {
        "lambda_q025": float(np.quantile(vals, 0.025)),
        "lambda_q975": float(np.quantile(vals, 0.975)),
    }
