from __future__ import annotations

from pathlib import Path
import re
import platform
import time
import os
import shutil

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from config import load_settings
from corpora import (
    load_common_voice_samples,
    load_massive_samples,
    load_mls_samples,
    load_speech_massive_samples,
)
from normalization import normalize_text, sentence_stream
from morphology import all_text_features
from speech_features import aggregate_speech_features
from locality import estimate_information_locality, choose_max_lag
from decay import fit_decay, bootstrap_lambda, memory_cost
from regression import fit_models
from utils import choose_device, write_json


LANGUAGE_FAMILY = {
    "English": "Germanic", "German": "Germanic", "Dutch": "Germanic", "Swedish": "Germanic",
    "French": "Romance", "Spanish": "Romance", "Italian": "Romance", "Portuguese": "Romance",
    "Russian": "Slavic", "Polish": "Slavic", "Czech": "Slavic",
    "Turkish": "Turkic", "Finnish": "Uralic", "Hungarian": "Uralic",
    "Indonesian": "Austronesian", "Vietnamese": "Austroasiatic",
    "Hindi": "Indo-Aryan", "Mandarin Chinese": "Sinitic",
    "Japanese": "Japonic", "Korean": "Koreanic",
}

CURRENT_ANALYSIS_VERSION = "2026-08-20-publication-consistency-v8"

SCRIPT = {
    "English": "Latin", "German": "Latin", "Dutch": "Latin", "Swedish": "Latin",
    "French": "Latin", "Spanish": "Latin", "Italian": "Latin", "Portuguese": "Latin",
    "Russian": "Cyrillic", "Polish": "Latin", "Czech": "Latin",
    "Turkish": "Latin", "Finnish": "Latin", "Hungarian": "Latin",
    "Indonesian": "Latin", "Vietnamese": "Latin", "Hindi": "Devanagari",
    "Mandarin Chinese": "Han", "Japanese": "Mixed-CJK", "Korean": "Hangul",
}


def _sampling_value(settings, sampling: dict, key: str, default):
    if key in sampling:
        return sampling[key]
    if key in settings.raw.get("sampling", {}):
        return settings.raw["sampling"][key]
    aliases = {
        "max_text_samples_per_language": ("max_text_utterances_per_language",),
        "max_text_chars_per_language_source": ("max_text_chars",),
        "max_speech_segments_per_language_source": ("max_speech_segments",),
        "min_text_characters": (),
    }
    for alias in aliases.get(key, ()):
        if alias in sampling:
            return sampling[alias]
        if alias in settings.raw.get("sampling", {}):
            return settings.raw["sampling"][alias]
    return default


def _full_cv_budgets(settings, sampling: dict) -> tuple[int, int, int]:
    """
    Final Common Voice analysis budgets. Text and time calibration come from
    the SAME canonical Common Voice v26 utterance population. Other corpora are
    not mixed into the primary scientific estimate.
    """
    char_budget = int(
        _sampling_value(
            settings,
            sampling,
            "max_text_chars_per_language_source",
            10_000_000,
        )
    )
    default_text_samples = max(20_000, min(150_000, char_budget // 40))
    text_samples = int(
        _sampling_value(
            settings,
            sampling,
            "max_text_samples_per_language",
            default_text_samples,
        )
    )
    speech_samples = int(
        _sampling_value(
            settings,
            sampling,
            "max_speech_segments_per_language_source",
            2_000,
        )
    )
    return char_budget, text_samples, speech_samples


def _free_bytes(path: Path) -> int:
    return int(shutil.disk_usage(path).free)


def _cleanup_common_voice_archive(archive_path: str | Path) -> None:
    """
    Delete a successfully processed Common Voice archive and the companion
    resumable-download files, while leaving all derived analysis products intact.

    This is deliberately called only after the language's locality/features
    have been computed and written to the in-memory result tables. If a
    language fails midway, the archive remains on disk so MDC can resume it.
    """
    archive = Path(archive_path)
    candidates = {
        archive,
        Path(str(archive) + ".part"),
        Path(str(archive) + ".checksum"),
    }

    # Also remove a sidecar checksum when the SDK uses a basename-derived name.
    if archive.suffixes:
        candidates.add(archive.with_name(archive.name + ".checksum"))

    for path in candidates:
        try:
            if path.is_file():
                path.unlink()
                print(f"[storage] deleted {path}")
        except OSError as exc:
            # Do not destroy a completed scientific run because cleanup failed.
            print(f"[storage] could not delete {path}: {exc}")



def _checkpoint_dir(results_root: Path) -> Path:
    d = results_root / "checkpoints"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _checkpoint_path(results_root: Path, language: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", language)
    return _checkpoint_dir(results_root) / f"{safe}.done.json"


def _is_completed(results_root: Path, language: str) -> bool:
    return _checkpoint_path(results_root, language).exists()


def _write_completed(
    results_root: Path,
    language: str,
    metadata: dict,
) -> None:
    path = _checkpoint_path(results_root, language)
    write_json(
        path,
        {
            "language": language,
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            **metadata,
        },
    )




def run(config_path: Path, mode: str, device: str = "auto", overwrite: bool = False):
    settings = load_settings(config_path, mode)
    device_used = choose_device(device)

    out_root = settings.results_root
    out_root.mkdir(parents=True, exist_ok=True)

    metadata_path = out_root / "run_metadata.json"
    if metadata_path.exists() and not overwrite:
        raise FileExistsError(
            f"{metadata_path} exists; use --overwrite for a new run."
        )

    sampling = settings.sampling()
    seed = int(sampling.get("seed", settings.raw.get("sampling", {}).get("seed", 20260815)))
    start = time.time()

    feature_rows: list[dict] = []
    curve_rows: list[dict] = []
    coverage_rows: list[dict] = []

    # Load persisted full-run results BEFORE doing anything that could overwrite
    # them. Empty/corrupt CSVs are treated as missing state, not fatal errors.
    if mode == "full":
        out_root.mkdir(parents=True, exist_ok=True)
        paths = {
            "features": out_root / "language_features.csv",
            "curves": out_root / "locality_curves.csv",
            "coverage": out_root / "source_coverage.csv",
        }
        for key, path in paths.items():
            if not path.exists() or path.stat().st_size == 0:
                continue
            try:
                frame = pd.read_csv(path)
            except (pd.errors.EmptyDataError, pd.errors.ParserError):
                continue
            if frame.empty:
                continue
            if key == "features" and "language" in frame.columns:
                feature_rows.extend(frame.to_dict(orient="records"))
            elif key == "curves" and {"language", "lag_characters"}.issubset(frame.columns):
                curve_rows.extend(frame.to_dict(orient="records"))
            elif key == "coverage" and "language" in frame.columns:
                coverage_rows.extend(frame.to_dict(orient="records"))

    def persist_results() -> None:
        features = pd.DataFrame(feature_rows)
        curves = pd.DataFrame(curve_rows)
        coverage = pd.DataFrame(coverage_rows)
        if not features.empty and "language" in features.columns:
            features = features.drop_duplicates(subset=["language"], keep="last")
        if not curves.empty and {"language", "lag_characters"}.issubset(curves.columns):
            curves = curves.drop_duplicates(subset=["language", "lag_characters"], keep="last")
        if not coverage.empty and "language" in coverage.columns:
            coverage = coverage.drop_duplicates(subset=["language"], keep="last")
        features.to_csv(out_root / "language_features.csv", index=False)
        curves.to_csv(out_root / "locality_curves.csv", index=False)
        coverage.to_csv(out_root / "source_coverage.csv", index=False)
        return features, curves, coverage

    def feature_exists(language: str) -> bool:
        for r in feature_rows:
            if str(r.get("language")) != language:
                continue
            # A result from an earlier estimator version is not a valid
            # checkpoint for the corrected analysis.
            if str(r.get("analysis_version", "")) == CURRENT_ANALYSIS_VERSION:
                return True
        return False

    # ------------------------------------------------------------
    # FULL MODE: Common Voice v26 is the primary and only scientific corpus.
    # ------------------------------------------------------------
    if mode == "full":
        char_budget, text_samples, speech_samples = _full_cv_budgets(settings, sampling)
        settings.data_root.mkdir(parents=True, exist_ok=True)
        cv_root = settings.data_root / "common_voice"
        cv_root.mkdir(parents=True, exist_ok=True)

        free_gb = shutil.disk_usage(settings.data_root).free / (1024 ** 3)
        minimum_free_gb = float(settings.raw.get("data", {}).get("minimum_free_gb", 120))
        if free_gb < minimum_free_gb:
            raise RuntimeError(
                f"FULL RUN STOPPED before downloading data: only {free_gb:.1f} GB free "
                f"at {settings.data_root}; need at least {minimum_free_gb:.1f} GB."
            )

        lp = dict(settings.raw.get("locality", {}))
        standard_max_lag = int(lp.get("max_lag_chars", 20))
        lp.setdefault("min_positive_it", 1e-5)
        lp.setdefault("bootstrap_reps", 300)
        lp.setdefault("train_chars", 5_000_000)
        lp.setdefault("valid_chars", 1_000_000)
        lp.setdefault("batch_size", 256)
        lp.setdefault("seq_len", 256)
        lp.setdefault("embedding_dim", 64)
        lp.setdefault("hidden_dim", 128)
        lp.setdefault("num_layers", 2)
        lp.setdefault("dropout", 0.1)
        lp.setdefault("epochs", 3)
        lp.setdefault("learning_rate", 0.002)
        lp.setdefault("weight_decay", 1e-5)

        min_text_characters = int(_sampling_value(settings, sampling, "min_text_characters", 20_000))

        for language, lang_code in settings.languages.items():
            print(f"\n=== {language} ({lang_code}) ===")

            # A checkpoint is valid only if the corresponding derived row still
            # exists. This prevents stale checkpoints from masking lost results.
            if _is_completed(out_root, language) and feature_exists(language):
                print(f"[RESUME] {language} already completed; skipping download and computation.")
                continue
            if _is_completed(out_root, language) and not feature_exists(language):
                print(
                    f"[RESUME] stale checkpoint for {language}; derived result is missing. "
                    "Recomputing."
                )
                try:
                    _checkpoint_path(out_root, language).unlink()
                except OSError:
                    pass

            try:
                cv_text, cv_speech, cv_meta = load_common_voice_samples(
                    language=language,
                    data_dir=cv_root,
                    max_texts=text_samples,
                    max_speech=speech_samples,
                    seed=seed,
                )

                # Keep complete utterances until the character budget is reached;
                # never cut an utterance in half. The same utterance list feeds
                # both the morphology/text statistics and the locality split.
                selected_text = []
                selected_chars = 0
                for u in cv_text:
                    n = len(normalize_text(u.text))
                    if selected_text and selected_chars + n > char_budget:
                        break
                    selected_text.append(u)
                    selected_chars += n

                if selected_chars < min_text_characters:
                    coverage_rows.append({
                        "language": language,
                        "text_characters": selected_chars,
                        "text_utterances": len(selected_text),
                        "n_speech_segments": len(selected_text),
                        "total_speech_seconds": float(sum(u.duration_s or 0.0 for u in selected_text)),
                        "status": "insufficient_text",
                        "analysis_version": CURRENT_ANALYSIS_VERSION,
                        "primary_source": "common_voice",
                        "archive": cv_meta["archive"],
                    })
                    persist_results()
                    print(f"[SKIP {language}] insufficient canonical text: {selected_chars:,} < {min_text_characters:,} characters")
                    continue

                analysis_texts = [normalize_text(u.text) for u in selected_text]
                corpus_text = sentence_stream(analysis_texts)
                max_lag, lag_rule = choose_max_lag(selected_chars, lp)
                # The speech/time variables must be computed on exactly the
                # same canonical utterance population used for the text/locality
                # analysis. `selected_text` is a subset of the canonical table,
                # so there is no independent speech sample here.
                speech_feats = aggregate_speech_features(selected_text, lang_code)
                spc = speech_feats.get("seconds_per_character", np.nan)
                if not np.isfinite(spc) or spc <= 0:
                    raise RuntimeError(f"No valid speech-time calibration for {language}.")

                print(
                    f"[Common Voice primary] chars={selected_chars:,} | "
                    f"speech_segments={len(cv_speech):,} | "
                    f"speech_seconds={speech_feats['total_speech_seconds']:.1f} | "
                    f"seconds/character={spc:.6f}"
                )

                morph_feats = all_text_features(
                    corpus_text,
                    seed=seed,
                    utterance_texts=analysis_texts,
                    entropy_order=5,
                )

                locality = estimate_information_locality(
                    language=language,
                    utterance_texts=analysis_texts,
                    seconds_per_character=float(spc),
                    max_lag=max_lag,
                    params=lp,
                    device=device_used,
                    seed=seed,
                )

                decay = fit_decay(
                    locality.lags,
                    locality.information,
                    locality.seconds_per_character,
                    positive_floor=float(lp["min_positive_it"]),
                    min_decay_points=int(lp.get("min_decay_points", 5)),
                )
                decay.update(
                    bootstrap_lambda(
                        locality.lags,
                        locality.information,
                        locality.seconds_per_character,
                        reps=int(lp["bootstrap_reps"]),
                        seed=seed,
                    )
                )
                decay["memory_cost_T"] = memory_cost(locality.lags, locality.information)
                decay["time_calibrated"] = True
                decay["locality_time_unit"] = "seconds"
                decay["primary_source"] = "Common Voice Scripted Speech 26.0"

                feature_rows.append({
                    "language": language,
                    "lang_code": lang_code,
                    "language_family": LANGUAGE_FAMILY[language],
                    "script": SCRIPT[language],
                    "primary_source": "common_voice",
                    "canonical_same_population": True,
                    "analysis_version": CURRENT_ANALYSIS_VERSION,
                    "common_voice_text_samples": len(selected_text),
                    "common_voice_speech_samples": len(selected_text),
                    **speech_feats,
                    **morph_feats,
                    **decay,
                    "locality_max_lag_used": int(max_lag),
                    "locality_lag_rule": lag_rule,
                    "locality_estimator": "character_kneser_ney_primary",
                })

                for lag, i_val in zip(locality.lags, locality.information):
                    curve_rows.append({
                        "language": language,
                        "lang_code": lang_code,
                        "lag_characters": lag,
                        "lag_seconds": lag * float(spc),
                        "I_t_bits": i_val,
                        "time_calibrated": True,
                        "primary_source": "common_voice",
                    })

                coverage_rows.append({
                    "language": language,
                    "text_characters": selected_chars,
                    "text_utterances": len(selected_text),
                    "n_speech_segments": speech_feats["n_speech_segments"],
                    "total_speech_seconds": speech_feats["total_speech_seconds"],
                    "speech_calibration_characters": int(sum(len(normalize_text(u.text)) for u in selected_text if u.duration_s and u.duration_s > 0)),
                    "seconds_per_character": spc,
                    "status": "processed",
                    "analysis_version": CURRENT_ANALYSIS_VERSION,
                    "locality_max_lag_used": int(max_lag),
                    "locality_lag_rule": lag_rule,
                    "primary_source": "common_voice",
                    "archive": cv_meta["archive"],
                })

                # Persist first. Only after derived outputs and checkpoint exist
                # do we remove the large raw archive.
                persist_results()
                _write_completed(
                    out_root,
                    language,
                    {
                        "lang_code": lang_code,
                        "analysis_version": CURRENT_ANALYSIS_VERSION,
                        "primary_source": "Common Voice Scripted Speech 26.0",
                        "archive": cv_meta["archive"],
                        "text_characters": selected_chars,
                        "speech_segments": len(cv_speech),
                        "seconds_per_character": float(spc),
                    },
                )
                _cleanup_common_voice_archive(cv_meta["archive"])

            except Exception as exc:
                print(
                    f"[CHECKPOINT] {language} was not completed; retaining any partial "
                    "Common Voice download and continuing to the next language."
                )
                coverage_rows.append({
                    "language": language,
                    "status": "failed",
                    "analysis_version": CURRENT_ANALYSIS_VERSION,
                    "primary_source": "common_voice",
                    "error": str(exc),
                })
                persist_results()
                continue

        features, curves, coverage = persist_results()

        if len(features) < len(settings.languages):
            missing = sorted(set(settings.languages) - set(features.get("language", [])))
            print(
                f"[FULL] {len(features)}/{len(settings.languages)} languages produced feature rows; "
                f"unavailable/insufficient languages: {missing}"
            )

        if len(features) >= 8:
            fit_models(features, out_root, include_interactions=True)
        else:
            print(
                f"[FULL] {len(features)} language(s) completed; "
                "cross-language regression not fitted (needs at least 8)."
            )

        print(f"[FULL] completed {len(features)}/{len(settings.languages)} languages.")
        _plot_results(features, curves, out_root)

        write_json(
            metadata_path,
            {
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "elapsed_seconds": time.time() - start,
                "python": platform.python_version(),
                "platform": platform.platform(),
                "device": device_used,
                "mode": mode,
                "languages": list(settings.languages.keys()),
                "primary_source": "Common Voice Scripted Speech 26.0",
                "config": settings.raw,
            },
        )
        return

    # ------------------------------------------------------------
    # PILOT MODE: lightweight supplemental sources only.
    # ------------------------------------------------------------
    text_char_budget = int(
        _sampling_value(settings, sampling, "max_text_chars_per_language_source", 400_000)
    )
    max_text_samples = int(
        _sampling_value(settings, sampling, "max_text_samples_per_language", 5_000)
    )
    max_speech = int(
        _sampling_value(settings, sampling, "max_speech_segments_per_language_source", 500)
    )
    min_chars = int(_sampling_value(settings, sampling, "min_text_characters", 20_000))

    for language, lang_code in settings.languages.items():
        print(f"\n=== {language} ({lang_code}) ===")
        texts: list = []
        speech: list = []

        for source_name, loader in (
            ("massive", lambda: load_massive_samples(language, max_text_samples, seed)),
            ("mls", lambda: load_mls_samples(language, max_text_samples, max_speech, seed)),
            ("speech_massive", lambda: load_speech_massive_samples(language, max_text_samples, max_speech, seed)),
        ):
            try:
                result = loader()
                if source_name == "massive":
                    texts.extend(result)
                    print(f"[MASSIVE] text={len(result)}")
                else:
                    t, s = result
                    texts.extend(t)
                    speech.extend(s)
                    print(f"[{source_name.upper()}] text={len(t)} speech={len(s)}")
            except Exception as exc:
                print(f"[{source_name.upper()}] unavailable: {exc}")

        selected = []
        total_chars = 0
        for u in texts:
            n = len(normalize_text(u.text))
            if selected and total_chars + n > text_char_budget:
                break
            selected.append(u)
            total_chars += n

        corpus_text = sentence_stream([u.text for u in selected])
        speech_feats = aggregate_speech_features(speech, lang_code)
        print(
            f"[pilot data] chars={total_chars:,} | "
            f"speech_segments={len(speech):,} | "
            f"time_calibrated={bool(np.isfinite(speech_feats.get('seconds_per_character', np.nan)))}"
        )

        if total_chars < min_chars:
            print(f"[PILOT SKIP {language}] insufficient text: {total_chars:,} characters")
            continue

        lp = dict(settings.raw.get("locality", {}))
        pilot_cfg = lp.pop("pilot", {})
        if isinstance(pilot_cfg, dict):
            lp.update(pilot_cfg)
        lp.setdefault("max_lag_chars", 12)
        lp.setdefault("train_chars", max(1, int(total_chars * 0.8)))
        lp.setdefault("valid_chars", max(1, int(total_chars * 0.2)))
        lp.setdefault("batch_size", 128)
        lp.setdefault("seq_len", 128)
        lp.setdefault("embedding_dim", 32)
        lp.setdefault("hidden_dim", 64)
        lp.setdefault("num_layers", 1)
        lp.setdefault("dropout", 0.0)
        lp.setdefault("epochs", 1)
        lp.setdefault("learning_rate", 0.002)
        lp.setdefault("weight_decay", 1e-5)
        lp.setdefault("min_positive_it", 1e-5)
        lp.setdefault("seeds", [seed])

        calibration = speech_feats.get("seconds_per_character", np.nan)
        if not np.isfinite(calibration) or calibration <= 0:
            calibration = 1.0

        estimate_information_locality(
            language=language,
            utterance_texts=[u.text for u in selected],
            seconds_per_character=float(calibration),
            max_lag=int(lp["max_lag_chars"]),
            params=lp,
            device=device_used,
            seed=seed,
        )

        print(
            f"[PILOT] locality curve estimated for {language}; "
            f"time_unit={'seconds' if calibration != 1.0 else 'character-lag units'}"
        )

    print(
        "\n[PILOT] complete. No scientific cross-language regression was fitted. "
        "The pilot is only a software/data-path check."
    )

def _plot_results(features: pd.DataFrame, curves: pd.DataFrame, out_root: Path):
    plot_dir = out_root / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)

    if not curves.empty:
        plt.figure(figsize=(10, 7))
        for language, group in curves.groupby("language"):
            plt.plot(group["lag_seconds"], group["I_t_bits"], alpha=0.6, label=language)
        plt.xlabel("Lag (seconds)")
        plt.ylabel("Estimated conditional mutual information (bits)")
        plt.title("Character-level information locality")
        if curves["language"].nunique() <= 20:
            plt.legend(fontsize=7, ncol=2)
        plt.tight_layout()
        plt.savefig(plot_dir / "locality_curves.png", dpi=200)
        plt.close()

    if not features.empty and "locality_lambda_per_s" in features.columns:
        finite = features[np.isfinite(features["locality_lambda_per_s"])]
        if not finite.empty:
            ordered = finite.sort_values("locality_lambda_per_s", ascending=False)
            plt.figure(figsize=(10, 7))
            plt.barh(ordered["language"], ordered["locality_lambda_per_s"])
            plt.xlabel("Decay rate λ (1/s)")
            plt.title("Information-locality decay")
            plt.gca().invert_yaxis()
            plt.tight_layout()
            plt.savefig(plot_dir / "decay_by_language.png", dpi=200)
            plt.close()
