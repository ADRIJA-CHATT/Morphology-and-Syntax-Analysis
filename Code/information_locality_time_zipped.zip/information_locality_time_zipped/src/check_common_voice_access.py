from pathlib import Path
import sys
from downloaders import CV_REGISTRY, preflight_common_voice
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / "additionals" / ".env")
rows = preflight_common_voice(list(CV_REGISTRY))
for row in rows:
    print(f"{row['language']}: {row['status']} | {row['dataset_id']} | {row['dataset_name']}")
print(f"Verified: {sum(r['status'] == 'verified' for r in rows)}/{len(rows)}")
