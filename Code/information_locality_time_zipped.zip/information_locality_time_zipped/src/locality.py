from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable, Sequence

import numpy as np
import torch
from torch import nn

from utils import stable_seed


@dataclass
class LocalityResult:
    language: str
    lags: list[int]
    surprisal: list[float]
    information: list[float]
    seconds_per_character: float


class CharLM(nn.Module):
    def __init__(self, vocab_size: int, embedding_dim: int, hidden_dim: int, layers: int, dropout: float):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, embedding_dim)
        self.rnn = nn.LSTM(
            embedding_dim,
            hidden_dim,
            num_layers=layers,
            batch_first=True,
            dropout=dropout if layers > 1 else 0.0,
        )
        self.out = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x, hidden=None):
        z = self.emb(x)
        z, hidden = self.rnn(z, hidden)
        return self.out(z), hidden


def make_vocab(texts: Sequence[str]):
    chars = sorted(set("".join(texts)))
    vocab = ["<pad>", "<eos>", "<unk>"] + chars
    stoi = {c: i for i, c in enumerate(vocab)}
    itos = {i: c for c, i in stoi.items()}
    return vocab, stoi, itos


def to_ids(text: str, stoi: dict[str, int], append_eos: bool = False) -> np.ndarray:
    unk = stoi["<unk>"]
    eos = stoi["<eos>"]
    ids = [stoi.get(c, unk) for c in text]
    if append_eos:
        ids.append(eos)
    return np.asarray(ids, dtype=np.int64)


def _stream_ids(texts: Sequence[str], stoi: dict[str, int]) -> np.ndarray:
    parts: list[np.ndarray] = []
    for text in texts:
        if not text:
            continue
        parts.append(to_ids(text, stoi, append_eos=True))
    if not parts:
        return np.empty(0, dtype=np.int64)
    return np.concatenate(parts)


def _char_count(text: str) -> int:
    return sum(not ch.isspace() for ch in text)


def _split_utterances(texts: Sequence[str], target_train_fraction: float = 0.8):
    usable = [t for t in texts if _char_count(t) >= 2]
    if len(usable) < 2:
        raise ValueError("Need at least two non-empty utterances for a held-out locality estimate.")

    n_total = len(usable)
    n_train = int(round(target_train_fraction * n_total))
    n_train = min(max(1, n_train), n_total - 1)
    train = usable[:n_train]
    valid = usable[n_train:]
    return train, valid


def build_examples(ids: np.ndarray, seq_len: int, max_examples: int) -> tuple[np.ndarray, np.ndarray]:
    if len(ids) < seq_len + 2:
        raise ValueError(
            f"Not enough training characters ({len(ids)}) for seq_len={seq_len}."
        )
    n = min(max_examples, max(1, len(ids) - seq_len))
    if n <= 0:
        raise ValueError("No training sequences could be constructed.")
    starts = np.linspace(0, len(ids) - seq_len - 1, n, dtype=int)
    x = np.stack([ids[s:s + seq_len] for s in starts])
    y = np.stack([ids[s + 1:s + seq_len + 1] for s in starts])
    return x, y


def train_char_lm(
    train_texts: Sequence[str],
    valid_texts: Sequence[str],
    max_lag: int,
    device: str,
    params: dict,
    language: str,
    seed: int,
):
    torch.manual_seed(stable_seed(language, "torch", base=seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(stable_seed(language, "cuda", base=seed))

    vocab, stoi, itos = make_vocab(train_texts)
    train_ids = _stream_ids(train_texts, stoi)

    model = CharLM(
        len(vocab),
        params["embedding_dim"],
        params["hidden_dim"],
        params["num_layers"],
        params["dropout"],
    ).to(device)

    opt = torch.optim.AdamW(
        model.parameters(),
        lr=params["learning_rate"],
        weight_decay=params["weight_decay"],
    )
    loss_fn = nn.CrossEntropyLoss()
    model.train()

    max_examples = max(2000, min(50000, max(1, len(train_ids) // max(1, params["seq_len"]))))
    x_np, y_np = build_examples(train_ids, params["seq_len"], max_examples=max_examples)
    order = np.arange(len(x_np))

    for epoch in range(params["epochs"]):
        np.random.default_rng(
            stable_seed(language, "epoch", epoch, base=seed)
        ).shuffle(order)
        for start in range(0, len(order), params["batch_size"]):
            idx = order[start:start + params["batch_size"]]
            x = torch.as_tensor(x_np[idx], dtype=torch.long, device=device)
            y = torch.as_tensor(y_np[idx], dtype=torch.long, device=device)
            opt.zero_grad(set_to_none=True)
            logits, _ = model(x)
            loss = loss_fn(logits.reshape(-1, logits.shape[-1]), y.reshape(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

    return model, vocab, stoi, valid_texts


@torch.no_grad()
def evaluate_windowed_surprisal(
    model: nn.Module,
    valid_texts: Sequence[str],
    max_lag: int,
    device: str,
    batch_size: int,
    seed: int,
    max_positions: int = 200_000,
) -> list[float]:
    """
    Estimate S_t for t=1,...,max_lag+1 on held-out utterances.

    Crucially, contexts never cross utterance boundaries. We evaluate only
    targets with at least max_lag+1 preceding characters inside the same
    utterance, so every S_t uses genuinely t-character linguistic context.
    This avoids artificial information carried across independently recorded
    Common Voice prompts.
    """
    model.eval()
    eligible: list[tuple[str, int]] = []
    max_context = max_lag + 1
    for text in valid_texts:
        if _char_count(text) <= max_context:
            continue
        for pos in range(max_context, len(text)):
            if text[pos].isspace():
                continue
            eligible.append((text, pos))

    if not eligible:
        raise ValueError("Held-out utterances are too short for the requested locality lag.")

    if len(eligible) > max_positions:
        rng = np.random.default_rng(seed)
        idx = np.sort(rng.choice(len(eligible), size=max_positions, replace=False))
        eligible = [eligible[int(i)] for i in idx]

    stoi = getattr(model, "_stoi_for_eval", None)
    if stoi is None:
        raise RuntimeError("Language-model vocabulary was not attached for evaluation.")

    surprisals: list[float] = []
    for lag in range(1, max_lag + 2):
        losses: list[float] = []
        for start in range(0, len(eligible), batch_size):
            batch = eligible[start:start + batch_size]
            seqs = [to_ids(text[pos - lag:pos], stoi) for text, pos in batch]
            targets = np.asarray([stoi.get(text[pos], stoi["<unk>"]) for text, pos in batch], dtype=np.int64)
            x = torch.as_tensor(np.stack(seqs), dtype=torch.long, device=device)
            y = torch.as_tensor(targets, dtype=torch.long, device=device)
            logits, _ = model(x)
            lp = torch.log_softmax(logits[:, -1, :], dim=-1)
            vals = -lp[torch.arange(len(batch), device=device), y]
            losses.extend(vals.detach().cpu().numpy().tolist())
        surprisals.append(float(np.mean(losses) / math.log(2)))

    return surprisals



# ---------------------------------------------------------------------------
# PRIMARY ESTIMATOR: held-out character-level interpolated Kneser-Ney
# ---------------------------------------------------------------------------

from collections import Counter, defaultdict


class CharacterKneserNey:
    """Interpolated Kneser-Ney character model of a single fixed order."""

    def __init__(self, order: int, discount: float = 0.75):
        if order < 1:
            raise ValueError("order must be >= 1")
        if not (0.0 < discount < 1.0):
            raise ValueError("discount must lie in (0, 1)")
        self.order = int(order)
        self.discount = float(discount)
        self.counts: dict[int, Counter] = {}
        self.context_counts: dict[int, Counter] = {}
        self.unique_followers: dict[int, dict[tuple[str, ...], set[str]]] = {}
        self.continuation_count: Counter = Counter()
        self.total_continuation_types = 0
        self.vocab: set[str] = set()

    def fit(self, texts: Sequence[str]):
        texts = [str(t) for t in texts if str(t)]
        self.vocab = set("".join(texts))
        if not self.vocab:
            raise ValueError("No characters available for Kneser-Ney training.")

        # A first-order KN model still needs bigram type statistics for its
        # continuation probability. Higher-order models need all lower orders.
        max_n = max(2, self.order)
        for n in range(1, max_n + 1):
            counts = Counter()
            for text in texts:
                if len(text) < n:
                    continue
                for i in range(n - 1, len(text)):
                    counts[tuple(text[i - n + 1:i + 1])] += 1
            self.counts[n] = counts

        for n in range(2, max_n + 1):
            ctx_counts = Counter()
            followers = defaultdict(set)
            for ng, c in self.counts[n].items():
                ctx = ng[:-1]
                ctx_counts[ctx] += c
                followers[ctx].add(ng[-1])
            self.context_counts[n] = ctx_counts
            self.unique_followers[n] = dict(followers)

        predecessor_types = defaultdict(set)
        for bigram in self.counts[2]:
            predecessor_types[bigram[-1]].add(bigram[:-1])
        self.continuation_count = Counter({c: len(v) for c, v in predecessor_types.items()})
        self.total_continuation_types = int(sum(self.continuation_count.values()))
        if self.total_continuation_types <= 0:
            self.continuation_count = Counter({c: self.counts[1][(c,)] for c in self.vocab})
            self.total_continuation_types = int(sum(self.continuation_count.values()))
        return self

    def _p_continuation(self, token: str) -> float:
        if token not in self.vocab:
            return 1e-12
        den = max(self.total_continuation_types, 1)
        return max(self.continuation_count.get(token, 0) / den, 1e-12)

    def _prob_recursive(self, context: tuple[str, ...], token: str, order: int) -> float:
        if order <= 1:
            return self._p_continuation(token)
        if len(context) < order - 1:
            return self._prob_recursive(context, token, order - 1)

        ctx = context[-(order - 1):]
        c_h = self.context_counts.get(order, {}).get(ctx, 0)
        if c_h <= 0:
            return self._prob_recursive(ctx[1:], token, order - 1)

        c_hw = self.counts[order].get(ctx + (token,), 0)
        followers = self.unique_followers[order].get(ctx, set())
        discounted = max(c_hw - self.discount, 0.0) / c_h
        backoff_weight = self.discount * len(followers) / c_h
        return max(
            discounted + backoff_weight * self._prob_recursive(ctx[1:], token, order - 1),
            1e-12,
        )

    def prob(self, context: Sequence[str], token: str) -> float:
        return self._prob_recursive(tuple(context[-(self.order - 1):]), token, self.order)

    def cross_entropy_on_positions(
        self,
        heldout: Sequence[str],
        positions: Sequence[tuple[int, int]],
    ) -> float:
        losses = []
        for text_idx, pos in positions:
            text = heldout[text_idx]
            context = text[pos - self.order:pos] if self.order > 0 else ""
            token = text[pos]
            losses.append(-math.log2(self.prob(tuple(context), token)))
        if not losses:
            raise ValueError(f"No held-out targets for order {self.order}.")
        return float(np.mean(losses))


def _kn_split_utterances(texts: Sequence[str], seed: int, train_fraction: float = 0.8):
    usable = [str(t) for t in texts if _char_count(str(t)) >= 2]
    if len(usable) < 2:
        raise ValueError("Need at least two utterances for held-out locality estimation.")
    rng = np.random.default_rng(stable_seed("kn_split", base=int(seed)))
    perm = rng.permutation(len(usable))
    usable = [usable[int(i)] for i in perm]
    n_train = min(max(1, int(round(train_fraction * len(usable)))), len(usable) - 1)
    return usable[:n_train], usable[n_train:]


def _take_until(texts: Sequence[str], cap: int) -> list[str]:
    if cap <= 0:
        return []
    out, total = [], 0
    for t in texts:
        n = _char_count(t)
        if out and total + n > cap:
            break
        out.append(t)
        total += n
        if total >= cap:
            break
    return out


def _monotone_nonincreasing(values: Sequence[float]) -> np.ndarray:
    return np.minimum.accumulate(np.asarray(values, dtype=float))


def _common_eval_positions(heldout: Sequence[str], max_order: int, max_positions: int, seed: int):
    eligible = []
    for idx, text in enumerate(heldout):
        if len(text) <= max_order:
            continue
        # Every character, including spaces, is a possible target. This matches
        # the character-stream definition used by the locality estimator.
        for pos in range(max_order, len(text)):
            eligible.append((idx, pos))
    if not eligible:
        raise ValueError("Held-out utterances are too short for the requested locality order.")
    if len(eligible) > max_positions:
        rng = np.random.default_rng(seed)
        chosen = rng.choice(len(eligible), size=max_positions, replace=False)
        chosen.sort()
        eligible = [eligible[int(i)] for i in chosen]
    return eligible


def choose_max_lag(n_characters: int, params: dict | None = None) -> tuple[int, str]:
    """Pre-specified data-availability rule applied before inspecting I_t."""
    params = params or {}
    standard = int(params.get("max_lag_chars", 20))
    threshold = int(params.get("low_resource_char_threshold", 100_000))
    low = int(params.get("low_resource_max_lag_chars", 10))
    if int(n_characters) < threshold:
        return max(1, min(low, standard)), "low_resource_fixed_lag"
    return max(1, standard), "standard_fixed_lag"


def estimate_information_locality_kn(
    language: str,
    utterance_texts: Sequence[str],
    seconds_per_character: float,
    max_lag: int = 20,
    params: dict | None = None,
    seed: int = 20260815,
) -> LocalityResult:
    """Primary locality estimator: held-out fixed-order character KN models.

    For each t, a separate order-t model is fit on training utterances and
    evaluated on the same held-out target positions. This follows the
    Hahn–Degen–Futrell held-out cross-entropy construction; the monotone
    correction is applied after estimating all S_t values.
    """
    params = dict(params or {})
    train_chars = int(params.get("kn_train_chars", params.get("train_chars", 500_000)))
    valid_chars = int(params.get("kn_valid_chars", params.get("valid_chars", 100_000)))
    eval_positions = int(params.get("kn_eval_positions", 100_000))
    discount = float(params.get("kn_discount", 0.75))
    train_fraction = float(params.get("train_fraction", 0.8))

    train, valid = _kn_split_utterances(utterance_texts, seed, train_fraction)
    train = _take_until(train, train_chars)
    valid = _take_until(valid, valid_chars)
    if not train or not valid:
        raise ValueError("Empty Kneser-Ney train/held-out partition.")

    max_order = int(max_lag) + 1
    positions = _common_eval_positions(
        valid,
        max_order=max_order,
        max_positions=eval_positions,
        seed=stable_seed(language, "kn_targets", base=seed),
    )

    S_raw = []
    for order in range(1, max_order + 1):
        model = CharacterKneserNey(order=order, discount=discount).fit(train)
        S_raw.append(model.cross_entropy_on_positions(valid, positions))

    S_corrected = _monotone_nonincreasing(S_raw)
    information = [
        float(S_corrected[t - 1] - S_corrected[t])
        for t in range(1, max_lag + 1)
    ]

    return LocalityResult(
        language=language,
        lags=list(range(1, max_lag + 1)),
        surprisal=S_corrected.tolist(),
        information=information,
        seconds_per_character=float(seconds_per_character),
    )


# Keep the neural estimator available explicitly as a secondary robustness
# analysis. The main pipeline uses the KN estimator above.


def estimate_information_locality(
    language: str,
    text: str | None = None,
    seconds_per_character: float = float("nan"),
    max_lag: int = 20,
    params: dict | None = None,
    device: str = "cpu",
    seed: int = 20260815,
    utterance_texts: Sequence[str] | None = None,
) -> LocalityResult:
    if utterance_texts is None:
        if text is None:
            raise ValueError("Provide either text or utterance_texts.")
        utterance_texts = [text]
    return estimate_information_locality_kn(
        language=language,
        utterance_texts=utterance_texts,
        seconds_per_character=seconds_per_character,
        max_lag=max_lag,
        params=params,
        seed=seed,
    )
