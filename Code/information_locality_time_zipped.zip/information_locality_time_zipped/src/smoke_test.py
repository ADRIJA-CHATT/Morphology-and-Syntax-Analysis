from pathlib import Path
from normalization import normalize_text, char_tokens, word_tokens
from entropy import morphology_redundancy
from speech_features import syllable_count
from decay import fit_decay, memory_cost

text = normalize_text("Hello, HELLO! This is a test.")
assert len(char_tokens(text)) == len(text)
assert len(word_tokens(text)) > 0
assert syllable_count("hello", "en") >= 1
m = morphology_redundancy(text, seed=1, n_reps=1)
assert "morphology_index" in m

lags = [1, 2, 3, 4, 5, 6]
info = [0.5, 0.35, 0.25, 0.17, 0.12, 0.08]
fit = fit_decay(lags, info, seconds_per_character=0.08)
assert fit["n_decay_points"] >= 5
assert memory_cost(lags, info) > 0
print("Smoke test passed.")
