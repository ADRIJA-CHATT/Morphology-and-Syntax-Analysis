from pathlib import Path
from config import load_settings
from downloaders import COMMON_VOICE_26, get_common_voice_details


def main():
    for language, spec in COMMON_VOICE_26.items():
        url = f"https://mozilladatacollective.com/datasets/{spec['id']}"
        try:
            d = get_common_voice_details(language)
            print(f"{language}: VERIFIED | {spec['id']} | {url}")
        except Exception as exc:
            print(f"{language}: CHECK/ACCESS NEEDED | {spec['id']} | {url}\n  {exc}")


if __name__ == "__main__":
    main()
