from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

from config import load_settings
from corpora import load_common_voice_samples
from normalization import normalize_text
from speech_features import aggregate_speech_features
from locality import estimate_information_locality, choose_max_lag
from decay import fit_decay

DEFAULT_SPLITS = [101, 202, 303, 404, 505, 606, 707, 808, 909, 1001]


def main():
    ap = argparse.ArgumentParser(description="Korean held-out KN locality split sensitivity")
    ap.add_argument("--config", required=True)
    ap.add_argument("--split-seeds", nargs="+", type=int, default=DEFAULT_SPLITS)
    args = ap.parse_args()

    settings = load_settings(Path(args.config), "full")
    if list(settings.languages.keys()) != ["Korean"]:
        raise RuntimeError("This script is intentionally Korean-only.")

    sampling = settings.sampling()
    root = settings.data_root / "common_voice"
    out = settings.results_root / "kn_sensitivity"
    out.mkdir(parents=True, exist_ok=True)

    cv_text, _, _ = load_common_voice_samples(
        language="Korean",
        data_dir=root,
        max_texts=int(sampling["max_text_samples_per_language"]),
        max_speech=int(sampling["max_speech_segments_per_language_source"]),
        seed=int(sampling.get("seed", 20260815)),
    )
    texts = [normalize_text(u.text) for u in cv_text]
    speech = aggregate_speech_features(cv_text, "ko")
    spc = float(speech["seconds_per_character"])
    params = dict(settings.raw.get("locality", {}))
    canonical_chars = sum(len(t) for t in texts)
    effective_max_lag, lag_rule = choose_max_lag(canonical_chars, params)
    print(f"Canonical Korean corpus: {len(texts)} utterances, {canonical_chars} chars")
    print(f"Seconds/character: {spc:.9f}")
    print(f"KN max lag: {effective_max_lag} ({lag_rule})")

    rows, curves = [], []
    for split_seed in args.split_seeds:
        loc = estimate_information_locality(
            language="Korean",
            utterance_texts=texts,
            seconds_per_character=spc,
            max_lag=int(effective_max_lag),
            params=params,
            seed=int(split_seed),
        )
        decay = fit_decay(
            loc.lags,
            loc.information,
            loc.seconds_per_character,
            positive_floor=float(params.get("min_positive_it", 1e-5)),
            min_decay_points=int(params.get("min_decay_points", 5)),
        )
        rows.append({
            "split_seed": split_seed,
            "canonical_chars": canonical_chars,
            "max_lag_used": effective_max_lag,
            "lag_rule": lag_rule,
            **decay,
        })
        for idx, (lag, val) in enumerate(zip(loc.lags, loc.information), start=1):
            s_corr = loc.surprisal[idx-1]
            curves.append({
                "split_seed": split_seed,
                "lag_characters": lag,
                "lag_seconds": lag * spc,
                "I_t_bits": val,
                "S_corrected_t_bits": s_corr,
            })

    df = pd.DataFrame(rows)
    cdf = pd.DataFrame(curves)
    df.to_csv(out / "kn_split_summary.csv", index=False)
    cdf.to_csv(out / "kn_split_curves.csv", index=False)

    vals = pd.to_numeric(df["locality_lambda_per_s"], errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    summary = pd.DataFrame([{
        "n_splits_total": int(len(df)),
        "n_splits_identified": int(len(vals)),
        "fraction_identified": float(len(vals) / len(df)) if len(df) else np.nan,
        "lambda_mean_identified": float(vals.mean()) if len(vals) else np.nan,
        "lambda_median_identified": float(vals.median()) if len(vals) else np.nan,
        "lambda_sd_identified": float(vals.std(ddof=1)) if len(vals) > 1 else np.nan,
        "lambda_q025_identified": float(vals.quantile(0.025)) if len(vals) else np.nan,
        "lambda_q975_identified": float(vals.quantile(0.975)) if len(vals) else np.nan,
    }])
    summary.to_csv(out / "kn_overall_summary.csv", index=False)
    print(summary.to_string(index=False))
    print(f"Outputs: {out}")


if __name__ == "__main__":
    main()
