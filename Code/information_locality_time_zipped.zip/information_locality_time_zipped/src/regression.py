from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import RidgeCV
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

CHAR_NUMERIC = [
    "syllable_rate_sps",
    "word_rate_wps",
    "speech_char_rate_cps",
    "mean_word_length_chars",
    "morphology_index",
    "word_structure_redundancy",
    "word_order_redundancy",
    "char_entropy_rate_bits",
    "lexical_ttr",
    "mean_duration_s",
    "n_chars",
    "morphology_x_syllable_rate",
    "word_length_x_syllable_rate",
    "morphology_x_word_length",
]

TIME_NUMERIC = [
    "syllable_rate_sps",
    "word_rate_wps",
    "mean_word_length_chars",
    "morphology_index",
    "word_structure_redundancy",
    "word_order_redundancy",
    "char_entropy_rate_bits",
    "lexical_ttr",
    "mean_duration_s",
    "n_chars",
    "morphology_x_word_length",
]
CATEGORICAL = ["language_family", "script"]


def _add_interactions(df: pd.DataFrame, include_interactions: bool = True) -> pd.DataFrame:
    out = df.copy()
    if include_interactions:
        out["morphology_x_syllable_rate"] = out["morphology_index"] * out["syllable_rate_sps"]
        out["word_length_x_syllable_rate"] = out["mean_word_length_chars"] * out["syllable_rate_sps"]
        out["morphology_x_word_length"] = out["morphology_index"] * out["mean_word_length_chars"]
    return out


def _make_transformer(df: pd.DataFrame, numeric_names: list[str]):
    numeric = [c for c in numeric_names if c in df.columns]
    categorical = [c for c in CATEGORICAL if c in df.columns]
    parts = [("num", Pipeline([
        ("imp", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ]), numeric)]
    if categorical:
        parts.append(("cat", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical))
    return ColumnTransformer(parts, remainder="drop")


def _fit_one(df: pd.DataFrame, outcome: str, numeric_names: list[str], out_dir: Path, prefix: str, include_interactions: bool):
    finite = np.isfinite(df[outcome].astype(float))
    df = df.loc[finite].copy()
    if len(df) < 8:
        raise RuntimeError(f"{prefix} regression needs at least 8 languages with finite {outcome}.")
    y_raw = df[outcome].astype(float).to_numpy()
    if np.any(y_raw <= 0):
        raise RuntimeError(f"{outcome} must be strictly positive for log-scale regression.")
    y = np.log(y_raw)
    X = _add_interactions(df, include_interactions)
    transformer = _make_transformer(X, numeric_names)
    alphas = np.logspace(-4, 4, 80)
    model = Pipeline([("features", transformer), ("ridge", RidgeCV(alphas=alphas, cv=LeaveOneOut()))])
    pred = cross_val_predict(model, X, y, cv=LeaveOneOut())
    model.fit(X, y)
    metrics = {
        "n_languages": int(len(df)),
        "outcome": outcome,
        "cv_r2_log_outcome": float(r2_score(y, pred)),
        "cv_mae_log_outcome": float(mean_absolute_error(y, pred)),
        "cv_rmse_log_outcome": float(np.sqrt(mean_squared_error(y, pred))),
        "selected_alpha": float(model.named_steps["ridge"].alpha_),
    }
    predictions = pd.DataFrame({
        "language": df["language"].values,
        "observed_log_outcome": y,
        "predicted_log_outcome": pred,
        "observed_outcome": y_raw,
        "predicted_outcome": np.exp(pred),
        "cv_residual": y - pred,
    })
    try:
        names = model.named_steps["features"].get_feature_names_out()
        coef = model.named_steps["ridge"].coef_
        coef_df = pd.DataFrame({"feature": names, "coefficient_log_outcome": coef})
        coef_df["abs_coefficient"] = np.abs(coef_df["coefficient_log_outcome"])
        coef_df = coef_df.sort_values("abs_coefficient", ascending=False)
    except Exception:
        coef_df = pd.DataFrame()
    pd.DataFrame([metrics]).to_csv(out_dir / f"regression_{prefix}_metrics.csv", index=False)
    predictions.to_csv(out_dir / f"regression_{prefix}_predictions.csv", index=False)
    coef_df.to_csv(out_dir / f"regression_{prefix}_coefficients.csv", index=False)
    return metrics


def fit_models(df: pd.DataFrame, out_dir: Path, include_interactions: bool = True):
    out_dir.mkdir(parents=True, exist_ok=True)
    # Primary scientific regression: character-domain decay. Speech rate is a
    # legitimate predictor here. Converting the fitted lambda to seconds is a
    # deterministic post-processing step, not the regression outcome.
    char_metrics = _fit_one(
        df, "locality_lambda_per_char", CHAR_NUMERIC, out_dir,
        "character", include_interactions,
    )
    # Secondary time-domain regression. We deliberately do NOT include
    # speech_char_rate_cps as an ordinary predictor because
    # lambda_s = lambda_char * speech_char_rate_cps, making that predictor
    # algebraically coupled to the outcome.
    time_metrics = _fit_one(
        df, "locality_lambda_per_s", TIME_NUMERIC, out_dir,
        "time_domain", include_interactions,
    )
    with open(out_dir / "regression_model_definition.json", "w", encoding="utf-8") as fh:
        json.dump({
            "primary_outcome": "log(locality_lambda_per_char)",
            "time_transformation": "locality_lambda_per_s = locality_lambda_per_char * speech_char_rate_cps",
            "time_domain_predictors_exclude_speech_char_rate_cps": True,
            "rationale": "Avoid algebraic leakage when speech rate is used as a substantive predictor of character-domain decay.",
        }, fh, indent=2)
    return char_metrics, time_metrics
