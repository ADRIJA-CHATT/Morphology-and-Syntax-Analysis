from pathlib import Path
import yaml
p = Path(__file__).resolve().parents[1] / "additionals" / "config_korean_test.yaml"
cfg = yaml.safe_load(p.read_text(encoding="utf-8"))
assert cfg["languages"] == {"Korean": "ko"}
assert cfg["data"]["root"] == "data_korean_test"
assert cfg["data"]["results"] == "results_korean_test"
assert "full" in cfg["sampling"]
print("config_korean_test.yaml: OK")
