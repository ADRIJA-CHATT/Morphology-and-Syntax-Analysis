# ================================================================
# protein.py
#
# PROTEIN QUANTITY vs PROTEIN QUALITY (DIAAS)
#
# TWO PLOTS
# ---------------------------------------------------------------
# 1. Protein (g / 100 g)      vs DIAAS
# 2. Protein (g / 100 kcal)   vs DIAAS
#
# Plant foods  = GREEN
# Animal foods = RED
#
# Quantity / calorie data:
#   USDA FoodData Central / USDA Standard Reference
#   (food-form-specific approximate values)
#
# Protein-quality data:
#   Primarily:
#   Nielsen et al., Nutrition Reviews (2026)
#   "Dietary Protein, DIAAS, Anabolism, and Cardiometabolic Health:
#    A Review and Future Perspectives"
#
#   Supplemented by direct food-specific DIAAS studies where useful.
#
# IMPORTANT:
# DIAAS is food-, preparation-, processing-, and
# reference-pattern-specific.
#
# ================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

try:
    from adjustText import adjust_text
except ImportError:
    raise ImportError(
        "\nThe package 'adjustText' is required.\n\n"
        "Install it with:\n"
        "    python -m pip install adjustText\n"
    )


# ================================================================
# DATASET
# ================================================================
#
# Protein and calorie values are approximate USDA reference values.
#
# DIAAS values are published values.
#
# Many of the new animal/dairy entries come directly from the
# 2026 Nutrition Reviews synthesis, which reports:
#
#   Nonfat dry milk powder        144
#   Bacon, smoked cooked          142
#   Milk protein concentrate      141
#   Pork loin, 63 C               139
#   Scrambled eggs                137
#   Casein micellar concentrate   137
#   Fried eggs                    135
#   Boiled eggs                   135
#   Whey protein concentrate      133
#   Ham, alternatively cured      133
#   Ribeye, 64 C                  130
#   Bologna                       128
#   Ham, conventionally cured    126
#   Whey protein isolate          125
#   Skimmed milk powder            123
#   Ground beef, raw              121
#   Beef jerky                    120
#   Salami                        120
#   Pork belly, raw               119
#   Lean beef 93%                 119
#   Pork loin, medium well        118
#   Bacon, smoked                 117
#   Pork loin, well done          117
#   Ribeye, medium rare           111
#   Lean beef 80%                 110
#   Ribeye, well done             107
#   Ground beef, cooked            99
#   Topside boiled                 99
#   Topside raw                    97
#   Topside pan-fried              98
#   Topside roasted                91
#   Topside grilled                80
#
# ================================================================


DATA = [

    # ============================================================
    # ======================= DAIRY ===============================
    # ============================================================

    {
        "Food": "Nonfat dry milk powder",
        "Type": "Animal",
        "Protein_100g": 36.2,
        "kcal_100g": 362,
        "DIAAS": 144,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Milk protein concentrate",
        "Type": "Animal",
        "Protein_100g": 80.0,
        "kcal_100g": 360,
        "DIAAS": 141,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Skimmed milk powder",
        "Type": "Animal",
        "Protein_100g": 34.0,
        "kcal_100g": 358,
        "DIAAS": 123,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Casein micellar concentrate",
        "Type": "Animal",
        "Protein_100g": 80.0,
        "kcal_100g": 360,
        "DIAAS": 137,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Casein",
        "Type": "Animal",
        "Protein_100g": 80.0,
        "kcal_100g": 370,
        "DIAAS": 117,
        "DIAAS_source": "Peer-reviewed DIAAS synthesis",
    },

    {
        "Food": "Whey protein concentrate",
        "Type": "Animal",
        "Protein_100g": 78.0,
        "kcal_100g": 370,
        "DIAAS": 133,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Whey protein isolate",
        "Type": "Animal",
        "Protein_100g": 82.0,
        "kcal_100g": 360,
        "DIAAS": 125,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Skim milk",
        "Type": "Animal",
        "Protein_100g": 3.4,
        "kcal_100g": 34,
        "DIAAS": 114,
        "DIAAS_source": "Peer-reviewed DIAAS literature",
    },

    {
        "Food": "Whole milk",
        "Type": "Animal",
        "Protein_100g": 3.2,
        "kcal_100g": 61,
        "DIAAS": 114,
        "DIAAS_source": "Peer-reviewed DIAAS literature",
    },


    # ============================================================
    # ======================== EGGS ===============================
    # ============================================================

    {
        "Food": "Boiled egg",
        "Type": "Animal",
        "Protein_100g": 12.6,
        "kcal_100g": 155,
        "DIAAS": 135,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Fried egg",
        "Type": "Animal",
        "Protein_100g": 13.6,
        "kcal_100g": 196,
        "DIAAS": 135,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Scrambled eggs",
        "Type": "Animal",
        "Protein_100g": 10.0,
        "kcal_100g": 149,
        "DIAAS": 137,
        "DIAAS_source": "Nutrition Reviews 2026",
    },


    # ============================================================
    # ======================== BEEF ===============================
    # ============================================================

    {
        "Food": "Ground beef, raw",
        "Type": "Animal",
        "Protein_100g": 20.0,
        "kcal_100g": 254,
        "DIAAS": 121,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Lean beef (93%)",
        "Type": "Animal",
        "Protein_100g": 26.0,
        "kcal_100g": 173,
        "DIAAS": 119,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Lean beef (80%)",
        "Type": "Animal",
        "Protein_100g": 25.0,
        "kcal_100g": 254,
        "DIAAS": 110,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ground beef, cooked",
        "Type": "Animal",
        "Protein_100g": 26.1,
        "kcal_100g": 217,
        "DIAAS": 99,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Beef jerky",
        "Type": "Animal",
        "Protein_100g": 33.2,
        "kcal_100g": 410,
        "DIAAS": 120,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Salami",
        "Type": "Animal",
        "Protein_100g": 22.6,
        "kcal_100g": 425,
        "DIAAS": 120,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Bologna",
        "Type": "Animal",
        "Protein_100g": 11.0,
        "kcal_100g": 310,
        "DIAAS": 128,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ribeye, 64 C",
        "Type": "Animal",
        "Protein_100g": 25.9,
        "kcal_100g": 291,
        "DIAAS": 130,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ribeye, medium rare",
        "Type": "Animal",
        "Protein_100g": 25.9,
        "kcal_100g": 291,
        "DIAAS": 111,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ribeye, well done",
        "Type": "Animal",
        "Protein_100g": 28.0,
        "kcal_100g": 300,
        "DIAAS": 107,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Topside steak, raw",
        "Type": "Animal",
        "Protein_100g": 22.0,
        "kcal_100g": 187,
        "DIAAS": 97,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Topside steak, boiled",
        "Type": "Animal",
        "Protein_100g": 29.0,
        "kcal_100g": 205,
        "DIAAS": 99,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Topside steak, pan-fried",
        "Type": "Animal",
        "Protein_100g": 28.0,
        "kcal_100g": 220,
        "DIAAS": 98,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Topside steak, roasted",
        "Type": "Animal",
        "Protein_100g": 29.0,
        "kcal_100g": 210,
        "DIAAS": 91,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Topside steak, grilled",
        "Type": "Animal",
        "Protein_100g": 30.0,
        "kcal_100g": 220,
        "DIAAS": 80,
        "DIAAS_source": "Nutrition Reviews 2026",
    },


    # ============================================================
    # ========================= PORK ===============================
    # ============================================================

    {
        "Food": "Pork loin, 63 C",
        "Type": "Animal",
        "Protein_100g": 27.3,
        "kcal_100g": 206,
        "DIAAS": 139,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Pork loin, medium well",
        "Type": "Animal",
        "Protein_100g": 27.3,
        "kcal_100g": 206,
        "DIAAS": 118,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Pork loin, well done",
        "Type": "Animal",
        "Protein_100g": 28.0,
        "kcal_100g": 215,
        "DIAAS": 117,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Pork belly",
        "Type": "Animal",
        "Protein_100g": 9.3,
        "kcal_100g": 518,
        "DIAAS": 119,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Bacon, smoked",
        "Type": "Animal",
        "Protein_100g": 12.0,
        "kcal_100g": 541,
        "DIAAS": 117,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Bacon, smoked cooked",
        "Type": "Animal",
        "Protein_100g": 37.0,
        "kcal_100g": 541,
        "DIAAS": 142,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ham, uncured",
        "Type": "Animal",
        "Protein_100g": 20.0,
        "kcal_100g": 145,
        "DIAAS": 124,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ham, conventionally cured",
        "Type": "Animal",
        "Protein_100g": 20.9,
        "kcal_100g": 145,
        "DIAAS": 126,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Ham, alternatively cured",
        "Type": "Animal",
        "Protein_100g": 20.9,
        "kcal_100g": 145,
        "DIAAS": 133,
        "DIAAS_source": "Nutrition Reviews 2026",
    },


    # ============================================================
    # ======================== CHICKEN =============================
    # ============================================================

    {
        "Food": "Chicken breast",
        "Type": "Animal",
        "Protein_100g": 31.0,
        "kcal_100g": 165,
        "DIAAS": 108,
        "DIAAS_source": "Published DIAAS measurement",
    },


    # ============================================================
    # ========================= LAMB ===============================
    # ============================================================

    {
        "Food": "Lamb",
        "Type": "Animal",
        "Protein_100g": 25.0,
        "kcal_100g": 206,
        "DIAAS": 117,
        "DIAAS_source": "Published DIAAS table",
    },


    # ============================================================
    # ========================== FISH ==============================
    # ============================================================

    {
        "Food": "Sardines, steamed",
        "Type": "Animal",
        "Protein_100g": 24.6,
        "kcal_100g": 208,
        "DIAAS": 105,
        "DIAAS_source": "Direct sardine DIAAS study",
    },


    # ============================================================
    # ======================= SOY / LEGUMES ========================
    # ============================================================

    {
        "Food": "Soybeans, cooked",
        "Type": "Plant",
        "Protein_100g": 18.2,
        "kcal_100g": 172,
        "DIAAS": 86.4,
        "DIAAS_source": "Quantitative soy DIAAS review",
    },

    {
        "Food": "Soy flour",
        "Type": "Plant",
        "Protein_100g": 52.0,
        "kcal_100g": 434,
        "DIAAS": 105,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Soy protein isolate",
        "Type": "Plant",
        "Protein_100g": 88.0,
        "kcal_100g": 335,
        "DIAAS": 98,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Tofu",
        "Type": "Plant",
        "Protein_100g": 17.3,
        "kcal_100g": 144,
        "DIAAS": 97,
        "DIAAS_source": "Direct food-specific study",
    },

    {
        "Food": "Mung beans, cooked",
        "Type": "Plant",
        "Protein_100g": 7.0,
        "kcal_100g": 105,
        "DIAAS": 94,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Peas, cooked",
        "Type": "Plant",
        "Protein_100g": 5.4,
        "kcal_100g": 84,
        "DIAAS": 88,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Chickpeas, cooked",
        "Type": "Plant",
        "Protein_100g": 8.9,
        "kcal_100g": 164,
        "DIAAS": 71,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Lentils, cooked",
        "Type": "Plant",
        "Protein_100g": 9.0,
        "kcal_100g": 116,
        "DIAAS": 65,
        "DIAAS_source": "Published DIAAS synthesis",
    },

    {
        "Food": "Kidney beans, cooked",
        "Type": "Plant",
        "Protein_100g": 8.7,
        "kcal_100g": 127,
        "DIAAS": 74,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Adzuki beans, cooked",
        "Type": "Plant",
        "Protein_100g": 7.5,
        "kcal_100g": 128,
        "DIAAS": 78,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Broad / fava beans",
        "Type": "Plant",
        "Protein_100g": 7.6,
        "kcal_100g": 110,
        "DIAAS": 87,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Pea protein concentrate",
        "Type": "Plant",
        "Protein_100g": 80.0,
        "kcal_100g": 390,
        "DIAAS": 73,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Seitan",
        "Type": "Plant",
        "Protein_100g": 24.7,
        "kcal_100g": 141,
        "DIAAS": 28,
        "DIAAS_source": "Direct food-specific study",
    },


    # ============================================================
    # ==================== CEREALS / GRAINS ========================
    # ============================================================

    {
        "Food": "Quinoa, cooked",
        "Type": "Plant",
        "Protein_100g": 4.4,
        "kcal_100g": 120,
        "DIAAS": 92,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "White rice, cooked",
        "Type": "Plant",
        "Protein_100g": 2.7,
        "kcal_100g": 130,
        "DIAAS": 64,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Brown rice, cooked",
        "Type": "Plant",
        "Protein_100g": 2.6,
        "kcal_100g": 123,
        "DIAAS": 42,
        "DIAAS_source": "Direct cereal DIAAS study",
    },

    {
        "Food": "Yellow dent maize",
        "Type": "Plant",
        "Protein_100g": 9.4,
        "kcal_100g": 365,
        "DIAAS": 48,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Barley",
        "Type": "Plant",
        "Protein_100g": 12.5,
        "kcal_100g": 354,
        "DIAAS": 51,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Rye",
        "Type": "Plant",
        "Protein_100g": 10.3,
        "kcal_100g": 338,
        "DIAAS": 47,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Wheat",
        "Type": "Plant",
        "Protein_100g": 13.7,
        "kcal_100g": 340,
        "DIAAS": 43,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Wheat bread",
        "Type": "Plant",
        "Protein_100g": 13.0,
        "kcal_100g": 247,
        "DIAAS": 19,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Quick oats",
        "Type": "Plant",
        "Protein_100g": 16.9,
        "kcal_100g": 389,
        "DIAAS": 67,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Dehulled oats",
        "Type": "Plant",
        "Protein_100g": 16.9,
        "kcal_100g": 389,
        "DIAAS": 77,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Potato, baked",
        "Type": "Plant",
        "Protein_100g": 2.5,
        "kcal_100g": 93,
        "DIAAS": 86,
        "DIAAS_source": "Published DIAAS review",
    },


    # ============================================================
    # ======================= NUTS / SEEDS =========================
    # ============================================================

    {
        "Food": "Pistachios, raw",
        "Type": "Plant",
        "Protein_100g": 20.2,
        "kcal_100g": 562,
        "DIAAS": 86,
        "DIAAS_source": "Direct pistachio DIAAS study",
    },

    {
        "Food": "Pistachios, roasted",
        "Type": "Plant",
        "Protein_100g": 20.9,
        "kcal_100g": 568,
        "DIAAS": 83,
        "DIAAS_source": "Direct pistachio DIAAS study",
    },

    {
        "Food": "Peanuts",
        "Type": "Plant",
        "Protein_100g": 25.8,
        "kcal_100g": 567,
        "DIAAS": 52,
        "DIAAS_source": "Nutrition Reviews 2026",
    },

    {
        "Food": "Almonds",
        "Type": "Plant",
        "Protein_100g": 21.2,
        "kcal_100g": 579,
        "DIAAS": 40,
        "DIAAS_source": "Published DIAAS calculation",
    },

    {
        "Food": "Sunflower seeds",
        "Type": "Plant",
        "Protein_100g": 20.8,
        "kcal_100g": 584,
        "DIAAS": 67,
        "DIAAS_source": "Published DIAAS calculation",
    },

    {
        "Food": "Flaxseed",
        "Type": "Plant",
        "Protein_100g": 18.3,
        "kcal_100g": 534,
        "DIAAS": 60,
        "DIAAS_source": "Direct human study",
    },
]


# ================================================================
# DATAFRAME
# ================================================================

df = pd.DataFrame(DATA)


# ================================================================
# PROTEIN PER 100 KCAL
# ================================================================

df["Protein_100kcal"] = (
    df["Protein_100g"]
    / df["kcal_100g"]
    * 100.0
)


# ================================================================
# QUALITY CLASS
# ================================================================

def quality_class(score):

    if score < 75:
        return "Below 75"

    elif score < 100:
        return "75–99"

    return "100+"


df["Quality_class"] = df["DIAAS"].apply(
    quality_class
)


# ================================================================
# COLORS
# ================================================================

PLANT_GREEN = "#49A86B"
ANIMAL_RED = "#E85D58"

df["Color"] = df["Type"].map(
    {
        "Plant": PLANT_GREEN,
        "Animal": ANIMAL_RED,
    }
)


# ================================================================
# MATPLOTLIB STYLE
# ================================================================

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "axes.edgecolor": "#222222",
        "axes.linewidth": 1.15,
        "axes.labelcolor": "#111111",
        "xtick.color": "#111111",
        "ytick.color": "#111111",
        "text.color": "#111111",
    }
)


# ================================================================
# LABEL SETTINGS
# ================================================================
#
# adjustText does the heavy lifting.
#
# These manual values only tweak font size for a few
# particularly long / important labels.
# ================================================================

SPECIAL_LABELS = {

    "Nonfat dry milk powder": {
        "fontsize": 9.0,
    },

    "Milk protein concentrate": {
        "fontsize": 9.0,
    },

    "Casein micellar concentrate": {
        "fontsize": 9.0,
    },

    "Whey protein concentrate": {
        "fontsize": 9.0,
    },

    "Whey protein isolate": {
        "fontsize": 9.5,
        "fontweight": "bold",
    },

    "Ground beef, cooked": {
        "fontsize": 9.0,
    },

    "Ground beef, raw": {
        "fontsize": 9.0,
    },

    "Pork loin, 63 C": {
        "fontsize": 9.0,
    },

    "Pork loin, medium well": {
        "fontsize": 9.0,
    },

    "Pork loin, well done": {
        "fontsize": 9.0,
    },
}


# ================================================================
# PLOT FUNCTION
# ================================================================

def make_plot(
    x_column,
    xlabel,
    title,
    subtitle,
    filename,
    x_max,
):

    # ------------------------------------------------------------
    # FIGURE
    # ------------------------------------------------------------

    fig, ax = plt.subplots(
        figsize=(15, 10.5)
    )

    fig.patch.set_facecolor(
        "#F5F8F9"
    )

    ax.set_facecolor(
        "#F5F8F9"
    )

    # ------------------------------------------------------------
    # LIMITS
    # ------------------------------------------------------------

    ax.set_xlim(
        0,
        x_max
    )

    ax.set_ylim(
        10,
        150
    )

    # ------------------------------------------------------------
    # GRID
    # ------------------------------------------------------------

    ax.grid(
        which="major",
        axis="both",
        color="#C8D1D6",
        linewidth=1.0,
        alpha=0.65
    )

    ax.set_axisbelow(True)

    # ------------------------------------------------------------
    # SCATTER
    # ------------------------------------------------------------

    for food_type, color in [
        ("Plant", PLANT_GREEN),
        ("Animal", ANIMAL_RED),
    ]:

        subset = df[
            df["Type"] == food_type
        ]

        ax.scatter(
            subset[x_column],
            subset["DIAAS"],
            s=470,
            color=color,
            edgecolors="white",
            linewidths=2.2,
            alpha=0.96,
            zorder=5,
            label=food_type,
        )

    # ------------------------------------------------------------
    # DIAAS REFERENCE LINES
    # ------------------------------------------------------------

    ax.axhline(
        75,
        color="#777777",
        linestyle="--",
        linewidth=1.1,
        alpha=0.75,
        zorder=1,
    )

    ax.axhline(
        100,
        color="#777777",
        linestyle=":",
        linewidth=1.1,
        alpha=0.75,
        zorder=1,
    )

    ax.text(
        x_max * 0.997,
        75.5,
        "DIAAS 75",
        fontsize=8.5,
        color="#666666",
        ha="right",
        va="bottom",
    )

    ax.text(
        x_max * 0.997,
        100.5,
        "DIAAS 100",
        fontsize=8.5,
        color="#666666",
        ha="right",
        va="bottom",
    )

    # ------------------------------------------------------------
    # LABELS
    # ------------------------------------------------------------

    texts = []

    for _, row in df.iterrows():

        settings = SPECIAL_LABELS.get(
            row["Food"],
            {}
        )

        fontsize = settings.get(
            "fontsize",
            9.3
        )

        fontweight = settings.get(
            "fontweight",
            "normal"
        )

        text = ax.text(
            row[x_column],
            row["DIAAS"],
            row["Food"],

            fontsize=fontsize,

            fontstyle="italic",

            fontweight=fontweight,

            color="#151515",

            bbox=dict(
                facecolor="#F5F8F9",
                edgecolor="none",
                alpha=0.86,
                boxstyle="round,pad=0.14",
            ),

            zorder=10,
        )

        texts.append(text)

    # ------------------------------------------------------------
    # AUTOMATIC COLLISION AVOIDANCE
    # ------------------------------------------------------------

    adjust_text(

        texts,

        x=df[x_column].values,

        y=df["DIAAS"].values,

        # Text-text repulsion
        force_text=(0.80, 1.25),

        # Text-point repulsion
        force_static=(0.45, 0.80),

        # Pull labels back toward their original points
        force_pull=(0.035, 0.08),

        # Initial explosion
        force_explode=(0.80, 1.25),

        # Increase separation
        expand=(1.18, 1.35),

        # Keep all labels inside plotting area
        ensure_inside_axes=True,

        # Allow two-dimensional movement
        only_move={
            "text": "xy",
            "static": "xy",
            "explode": "xy",
            "pull": "xy",
        },

        # Prevent crossing connector lines where possible
        prevent_crossings=True,

        # Connector lines
        arrowprops=dict(
            arrowstyle="-",
            color="#777777",
            linewidth=0.60,
            alpha=0.55,
            shrinkA=5,
            shrinkB=5,
        ),

        # Dense dataset needs more iterations
        iter_lim=2500,
    )

    # ------------------------------------------------------------
    # AXES LABELS
    # ------------------------------------------------------------

    ax.set_xlabel(
        xlabel,
        fontsize=19,
        fontweight="bold",
        fontstyle="italic",
        labelpad=14,
    )

    ax.set_ylabel(
        "Protein Quality (DIAAS)",
        fontsize=19,
        fontweight="bold",
        fontstyle="italic",
        labelpad=14,
    )

    # ------------------------------------------------------------
    # TICKS
    # ------------------------------------------------------------

    ax.tick_params(
        axis="both",
        labelsize=12,
        length=0,
        pad=7,
    )

    # ------------------------------------------------------------
    # SPINES
    # ------------------------------------------------------------

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # ------------------------------------------------------------
    # TITLE
    # ------------------------------------------------------------

    fig.text(
        0.5,
        0.965,
        title,
        ha="center",
        va="top",
        fontsize=29,
        fontweight="bold",
    )

    # ------------------------------------------------------------
    # SUBTITLE
    # ------------------------------------------------------------

    fig.text(
        0.5,
        0.925,
        subtitle,
        ha="center",
        va="top",
        fontsize=14.5,
        fontstyle="italic",
    )

    # ------------------------------------------------------------
    # LEGEND
    # ------------------------------------------------------------

    ax.legend(
        loc="upper left",
        bbox_to_anchor=(
            0.003,
            0.995,
        ),
        frameon=False,
        fontsize=12.5,
        ncol=2,
        handletextpad=0.4,
        columnspacing=1.2,
    )

    # ------------------------------------------------------------
    # SOURCE NOTE
    # ------------------------------------------------------------

    fig.text(
        0.055,
        0.037,
        "Protein/calorie values: USDA FoodData Central / "
        "USDA Standard Reference. "
        "DIAAS: published food-specific measurements and reviews.",
        ha="left",
        va="bottom",
        fontsize=8.3,
        color="#555555",
    )

    fig.text(
        0.055,
        0.017,
        "DIAAS is preparation-, processing-, and study-specific; "
        "values are not universal constants for an entire food.",
        ha="left",
        va="bottom",
        fontsize=8.3,
        color="#555555",
    )

    # ------------------------------------------------------------
    # LAYOUT
    # ------------------------------------------------------------

    plt.subplots_adjust(
        left=0.095,
        right=0.975,
        top=0.855,
        bottom=0.12,
    )

    # ------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------

    plt.savefig(
        filename,
        dpi=350,
        bbox_inches="tight",
        facecolor=fig.get_facecolor(),
    )

    plt.show()

    plt.close(fig)


# ================================================================
# PLOT 1
# ================================================================

make_plot(

    x_column="Protein_100g",

    xlabel="Protein per 100 g food (g)",

    title="RANKING PROTEIN QUALITY",

    subtitle=(
        "COMPARING PROTEIN QUANTITY AND QUALITY "
        "OF COMMON PLANT AND ANIMAL FOODS"
    ),

    filename="protein_per_100g_vs_DIAAS.png",

    x_max=90,
)


# ================================================================
# PLOT 2
# ================================================================

make_plot(

    x_column="Protein_100kcal",

    xlabel="Protein per 100 Calories (g)",

    title="RANKING PROTEIN QUALITY",

    subtitle=(
        "COMPARING PROTEIN QUALITY AND CALORIE EFFICIENCY "
        "OF COMMON PLANT AND ANIMAL FOODS"
    ),

    filename="protein_per_100kcal_vs_DIAAS.png",

    x_max=30,
)


# ================================================================
# SAVE COMPLETE DATASET
# ================================================================

df.to_csv(
    "protein_quality_quantity_dataset.csv",
    index=False,
)


# ================================================================
# SAVE A SMALL AUDIT TABLE SORTED BY DIAAS
# ================================================================

audit_df = df[
    [
        "Food",
        "Type",
        "Protein_100g",
        "kcal_100g",
        "Protein_100kcal",
        "DIAAS",
        "DIAAS_source",
    ]
].sort_values(
    "DIAAS",
    ascending=False,
)

audit_df.to_csv(
    "protein_quality_audit_table.csv",
    index=False,
)


# ================================================================
# CONSOLE OUTPUT
# ================================================================

print()
print("=" * 90)
print("PROTEIN QUALITY ANALYSIS COMPLETE")
print("=" * 90)

print()
print("Created:")
print("  protein_per_100g_vs_DIAAS.png")
print("  protein_per_100kcal_vs_DIAAS.png")
print("  protein_quality_quantity_dataset.csv")
print("  protein_quality_audit_table.csv")

print()
print("=" * 90)
print("NUMBER OF FOODS")
print("=" * 90)

print(
    df["Type"]
    .value_counts()
    .to_string()
)

print()
print("=" * 90)
print("ANIMAL FOODS")
print("=" * 90)

print(
    df[
        df["Type"] == "Animal"
    ][
        [
            "Food",
            "Protein_100g",
            "kcal_100g",
            "Protein_100kcal",
            "DIAAS",
        ]
    ]
    .sort_values(
        "DIAAS",
        ascending=False,
    )
    .to_string(index=False)
)

print()
print("=" * 90)
print("PLANT FOODS")
print("=" * 90)

print(
    df[
        df["Type"] == "Plant"
    ][
        [
            "Food",
            "Protein_100g",
            "kcal_100g",
            "Protein_100kcal",
            "DIAAS",
        ]
    ]
    .sort_values(
        "DIAAS",
        ascending=False,
    )
    .to_string(index=False)
)

print()
print("Done.")