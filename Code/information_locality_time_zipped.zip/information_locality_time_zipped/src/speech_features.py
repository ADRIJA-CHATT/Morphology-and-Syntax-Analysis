from __future__ import annotations

import unicodedata

from normalization import normalize_text

VOWELS = {
    "en": set("aeiouy"), "de": set("aeiouyäöü"), "nl": set("aeiouy"),
    "sv": set("aeiouyåäö"), "fr": set("aeiouyàâäæéèêëîïôöœùûüÿ"),
    "es": set("aeiouáéíóúü"), "it": set("aeiouàèéìíîòóùú"),
    "pt": set("aeiouáàâãéêíóôõúü"), "ru": set("аеёиоуыэюя"),
    "pl": set("aąeęiouóy"), "cs": set("aáeéěiíoóuúůyý"),
    "tr": set("aeıioöuü"), "fi": set("aeiouyäö"), "hu": set("aáeéiíoóöőuúüű"),
    "id": set("aeiou"), "vi": set("aăâeêioôơuưy"),
    "hi": set("अआइईउऊएऐओऔ"), "zh": set(), "ja": set(), "ko": set(),
}


def _clean(text: str) -> str:
    return normalize_text(str(text))


def canonical_character_count(text: str) -> int:
    """Count every character in the normalized utterance, including spaces."""
    return len(_clean(text))


def _word_count(text: str) -> int:
    return len(_clean(text).split())


def syllable_count(text: str, lang_code: str) -> int:
    text = unicodedata.normalize("NFC", _clean(text).lower())
    if not text:
        return 0
    if lang_code in {"zh", "ja"}:
        return max(1, sum(1 for c in text if unicodedata.category(c).startswith("L")))
    if lang_code == "ko":
        return max(1, sum(1 for c in text if "\uac00" <= c <= "\ud7a3"))
    if lang_code == "hi":
        vowels = VOWELS["hi"]
        return max(1, sum(c in vowels for c in text))
    vowels = VOWELS.get(lang_code, set("aeiou"))
    count = 0
    prev = False
    for ch in text:
        is_v = ch in vowels
        if is_v and not prev:
            count += 1
        prev = is_v
    return max(1, count)


def aggregate_speech_features(utterances, lang_code: str) -> dict:
    durations = []
    chars = []
    words = []
    syllables = []

    for u in utterances:
        if u.duration_s is None or u.duration_s <= 0:
            continue
        text = _clean(u.text)
        n_chars = canonical_character_count(text)
        n_words = _word_count(text)
        n_syll = syllable_count(text, lang_code)
        if n_chars <= 0:
            continue
        durations.append(float(u.duration_s))
        chars.append(n_chars)
        words.append(n_words)
        syllables.append(n_syll)

    if not durations:
        return {
            "n_speech_segments": 0,
            "speech_characters": 0,
            "total_speech_seconds": 0.0,
            "mean_duration_s": float("nan"),
            "speech_char_rate_cps": float("nan"),
            "word_rate_wps": float("nan"),
            "syllable_rate_sps": float("nan"),
            "seconds_per_character": float("nan"),
        }

    total_seconds = sum(durations)
    total_chars = sum(chars)
    total_words = sum(words)
    total_syllables = sum(syllables)

    return {
        "n_speech_segments": len(durations),
        "speech_characters": int(total_chars),
        "total_speech_seconds": float(total_seconds),
        "mean_duration_s": float(total_seconds / len(durations)),
        "speech_char_rate_cps": float(total_chars / total_seconds),
        "word_rate_wps": float(total_words / total_seconds),
        "syllable_rate_sps": float(total_syllables / total_seconds),
        "seconds_per_character": float(total_seconds / total_chars),
    }
