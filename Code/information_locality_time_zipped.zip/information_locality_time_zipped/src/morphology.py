from __future__ import annotations

import re
from typing import Sequence

import numpy as np

from entropy import entropy_rate_from_utterances
from normalization import normalize_text

_TOKEN_RE = re.compile(r"\S+", re.UNICODE)
ESTIMATOR_VERSION = "koplenig_lz_longest_match_v5"


def _words(text: str) -> list[str]:
    return _TOKEN_RE.findall(normalize_text(text))


def _mean_lengths(words: list[str]) -> tuple[float, float]:
    if not words:
        return float("nan"), float("nan")
    x = np.fromiter((len(w) for w in words), dtype=np.float64)
    return float(x.mean()), float(np.median(x))


def _shuffle_word_order(utterances: Sequence[str], rng: np.random.Generator) -> list[str]:
    """Randomize word order within each utterance, preserving each utterance's lexicon."""
    out = []
    for text in utterances:
        words = _words(text)
        if len(words) >= 2:
            rng.shuffle(words)
        out.append(" ".join(words))
    return out


def _mask_word_structure(utterances: Sequence[str], rng: np.random.Generator) -> list[str]:
    """
    Mask intra-lexical regularities following Koplenig et al.:
    every word type of length >= 2 is mapped to one unique random string of
    the same length, while every token of that type receives the same mapping.
    Word lengths, token/type frequencies, and word order are preserved.
    """
    original_words = [_words(t) for t in utterances]
    alphabet = sorted({c for ws in original_words for w in ws for c in w})
    if not alphabet:
        return [" ".join(ws) for ws in original_words]

    mapping: dict[str, str] = {}
    used: set[str] = set()
    for ws in original_words:
        for word in ws:
            if len(word) < 2 or word in mapping:
                continue
            # Construct a random equal-length sequence and avoid reusing the
            # same replacement for different word types whenever feasible.
            replacement = "".join(rng.choice(alphabet, size=len(word)).tolist())
            attempts = 0
            while replacement in used and attempts < 100:
                replacement = "".join(rng.choice(alphabet, size=len(word)).tolist())
                attempts += 1
            mapping[word] = replacement
            used.add(replacement)

    return [
        " ".join(mapping.get(word, word) for word in ws)
        for ws in original_words
    ]


def _entropy_triplet(
    utterance_texts: Sequence[str],
    seed: int,
) -> tuple[float, float, float]:
    original = [normalize_text(t) for t in utterance_texts if normalize_text(t)]
    if not original:
        return float("nan"), float("nan"), float("nan")

    h_original = entropy_rate_from_utterances(original, seed=seed)
    rng_order = np.random.default_rng(seed + 101)
    order_destroyed = _shuffle_word_order(original, rng_order)
    h_order = entropy_rate_from_utterances(order_destroyed, seed=seed)

    rng_structure = np.random.default_rng(seed + 202)
    structure_masked = _mask_word_structure(original, rng_structure)
    h_structure = entropy_rate_from_utterances(structure_masked, seed=seed)

    return h_original, h_order, h_structure


def all_text_features(
    text: str,
    seed: int = 20260815,
    utterance_texts: Sequence[str] | None = None,
    entropy_order: int = 5,
) -> dict[str, float | str]:
    """Compute lexical features on the canonical utterance population.

    `text` remains for API compatibility. The scientific counts (n_chars,
    words, mean utterance length) are computed from the normalized utterances
    themselves, so synthetic boundary spaces used only by the Koplenig-style
    entropy corpus do not contaminate the speech/locality population counts.
    """
    _ = entropy_order
    if utterance_texts:
        normalized_utts = [normalize_text(t) for t in utterance_texts if normalize_text(t)]
    else:
        normalized_utts = [normalize_text(text)] if normalize_text(text) else []

    words_by_utt = [_words(t) for t in normalized_utts]
    words = [w for ws in words_by_utt for w in ws]
    n_words = len(words)
    n_chars = int(sum(len(t) for t in normalized_utts))
    mean_len, median_len = _mean_lengths(words)
    n_types = len(set(words))
    ttr = n_types / n_words if n_words else float("nan")
    utt_lengths = [len(t) for t in normalized_utts]
    mean_chars_per_utterance = float(np.mean(utt_lengths)) if utt_lengths else float("nan")

    h_original, h_order, h_structure = _entropy_triplet(normalized_utts, seed=seed)
    d_order = h_order - h_original if np.isfinite(h_order) and np.isfinite(h_original) else float("nan")
    d_structure = h_structure - h_original if np.isfinite(h_structure) and np.isfinite(h_original) else float("nan")
    denom = d_order + d_structure if np.isfinite(d_order) and np.isfinite(d_structure) else float("nan")
    if np.isfinite(d_order) and np.isfinite(d_structure) and d_order >= 0 and d_structure >= 0 and denom > 0:
        morphology_index = float(d_structure / denom)
        morphology_status = "identified"
    else:
        morphology_index = float("nan")
        morphology_status = "not_identified_nonnegative_redundancy_required"

    morphology_corpus_characters = int(sum(len(t) for t in normalized_utts) + max(len(normalized_utts) - 1, 0))
    return {
        "n_words": float(n_words),
        "n_word_types": float(n_types),
        "mean_word_length_chars": mean_len,
        "median_word_length_chars": median_len,
        "lexical_ttr": ttr,
        "mean_chars_per_utterance": mean_chars_per_utterance,
        "H_original": h_original,
        "H_order": h_order,
        "H_structure": h_structure,
        "word_order_redundancy": d_order,
        "word_structure_redundancy": d_structure,
        "word_order_redundancy_raw": d_order,
        "word_structure_redundancy_raw": d_structure,
        "morphology_index": morphology_index,
        "morphology_index_status": morphology_status,
        "morphology_estimator_version": ESTIMATOR_VERSION,
        "n_chars": float(n_chars),
        "char_entropy_rate_bits": h_original,
        "morphology_corpus_characters": float(morphology_corpus_characters),
        "morphology_boundary_spaces": float(max(len(normalized_utts) - 1, 0)),
        "morphology_character_definition": "normalized_utterances_joined_by_single_spaces; Koplenig-style entropy-rate corpus",
    }
