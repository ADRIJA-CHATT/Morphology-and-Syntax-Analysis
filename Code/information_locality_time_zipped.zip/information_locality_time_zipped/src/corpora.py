from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import csv
import io
import tarfile
import zipfile
from typing import Any

import numpy as np
import pandas as pd

from normalization import normalize_text
from utils import reservoir_append, stable_seed
from downloaders import download_common_voice, hf_download_exact


@dataclass
class Utterance:
    language: str
    text: str
    duration_s: float | None
    source: str
    speaker: str | None = None
    clip_path: str | None = None


# These are SUPPLEMENTAL PILOT sources only.
# The FULL scientific run does not use them.
MASSIVE_LOCALES = {
    "English": "en-US", "German": "de-DE", "Dutch": "nl-NL", "Swedish": "sv-SE",
    "French": "fr-FR", "Spanish": "es-ES", "Italian": "it-IT", "Portuguese": "pt-PT",
    "Russian": "ru-RU", "Polish": "pl-PL", "Turkish": "tr-TR", "Finnish": "fi-FI",
    "Hungarian": "hu-HU", "Indonesian": "id-ID", "Vietnamese": "vi-VN", "Hindi": "hi-IN",
    "Mandarin Chinese": "zh-CN", "Japanese": "ja-JP", "Korean": "ko-KR",
}

MLS_CONFIGS = {
    "German": "german", "Dutch": "dutch", "French": "french",
    "Spanish": "spanish", "Italian": "italian", "Portuguese": "portuguese",
    "Polish": "polish",
}

SPEECH_MASSIVE_CONFIGS = {
    "German": "de-DE", "Spanish": "es-ES", "French": "fr-FR",
    "Hungarian": "hu-HU", "Korean": "ko-KR", "Dutch": "nl-NL",
    "Polish": "pl-PL", "Portuguese": "pt-PT", "Russian": "ru-RU",
    "Turkish": "tr-TR", "Vietnamese": "vi-VN",
}

# MASSIVE Parquet conversion revision known to contain locale/massive-train.parquet.
MASSIVE_PARQUET_REVISION = "1a5b2b362bcb4a6f5694396ee1ab577f91583ce2"


def _float_or_none(value: Any) -> float | None:
    try:
        if value is None or pd.isna(value):
            return None
        return float(value)
    except Exception:
        return None


def load_massive_samples(language: str, max_texts: int, seed: int) -> list[Utterance]:
    locale = MASSIVE_LOCALES.get(language)
    if locale is None:
        return []

    path = hf_download_exact(
        "AmazonScience/massive",
        f"{locale}/massive-train.parquet",
        revision=MASSIVE_PARQUET_REVISION,
    )
    df = pd.read_parquet(path, columns=["utt"])

    rng = np.random.default_rng(stable_seed(language, "massive", base=seed))
    out: list[Utterance] = []
    seen = 0

    for value in df["utt"].astype(str):
        text = normalize_text(value)
        if len(text) < 2:
            continue
        seen = reservoir_append(
            out,
            Utterance(language, text, None, "massive"),
            seen,
            max_texts,
            rng,
        )

    return out


def load_mls_samples(
    language: str,
    max_texts: int,
    max_speech: int,
    seed: int,
) -> tuple[list[Utterance], list[Utterance]]:
    config = MLS_CONFIGS.get(language)
    if config is None:
        return [], []

    path = hf_download_exact(
        "facebook/multilingual_librispeech",
        f"{config}/1_hours-00000-of-00001.parquet",
    )
    df = pd.read_parquet(path)

    required = {"transcript", "audio_duration"}
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(
            f"MLS {config} is missing required columns: {sorted(missing)}"
        )

    rng = np.random.default_rng(stable_seed(language, "mls", base=seed))
    texts: list[Utterance] = []
    speech: list[Utterance] = []
    seen_t = seen_s = 0

    for _, row in df.iterrows():
        text = normalize_text(str(row.get("transcript") or ""))
        if len(text) < 2:
            continue

        duration = _float_or_none(row.get("audio_duration"))
        speaker = str(row.get("speaker_id")) if row.get("speaker_id") is not None else None
        u = Utterance(language, text, duration, "mls", speaker)

        seen_t = reservoir_append(texts, u, seen_t, max_texts, rng)
        if duration is not None and duration > 0:
            seen_s = reservoir_append(speech, u, seen_s, max_speech, rng)

    return texts, speech


def _audio_duration(value: Any) -> float | None:
    if not isinstance(value, dict):
        return None

    for key in ("duration", "audio_duration"):
        value_d = _float_or_none(value.get(key))
        if value_d is not None:
            return value_d

    blob = value.get("bytes")
    if blob:
        try:
            import soundfile as sf
            return float(sf.info(io.BytesIO(blob)).duration)
        except Exception:
            return None

    return None


def load_speech_massive_samples(
    language: str,
    max_texts: int,
    max_speech: int,
    seed: int,
) -> tuple[list[Utterance], list[Utterance]]:
    config = SPEECH_MASSIVE_CONFIGS.get(language)
    if config is None:
        return [], []

    path = hf_download_exact(
        "FBK-MT/Speech-MASSIVE",
        f"{config}/train_115-00000-of-00001.parquet",
    )
    df = pd.read_parquet(path)

    text_col = next(
        (c for c in ("transcription", "text", "utt") if c in df.columns),
        None,
    )
    if text_col is None:
        raise RuntimeError(
            f"Speech-MASSIVE {config} has no transcript column. Columns: {list(df.columns)}"
        )

    rng = np.random.default_rng(stable_seed(language, "speech_massive", base=seed))
    texts: list[Utterance] = []
    speech: list[Utterance] = []
    seen_t = seen_s = 0

    for _, row in df.iterrows():
        text = normalize_text(str(row.get(text_col) or ""))
        if len(text) < 2:
            continue

        duration = None
        for key in ("duration", "audio_duration"):
            if key in df.columns:
                duration = _float_or_none(row.get(key))
                if duration is not None:
                    break

        if duration is None and "audio" in df.columns:
            duration = _audio_duration(row.get("audio"))

        speaker = str(row.get("speaker_id")) if row.get("speaker_id") is not None else None
        u = Utterance(language, text, duration, "speech_massive", speaker)

        seen_t = reservoir_append(texts, u, seen_t, max_texts, rng)
        if duration is not None and duration > 0:
            seen_s = reservoir_append(speech, u, seen_s, max_speech, rng)

    return texts, speech


def _open_cv_archive(path: Path):
    name = path.name.lower()
    if name.endswith((".tar.gz", ".tgz")):
        return tarfile.open(path, "r:gz")
    if name.endswith(".tar"):
        return tarfile.open(path, "r:")
    if name.endswith(".zip"):
        return zipfile.ZipFile(path)
    raise RuntimeError(f"Unsupported Common Voice archive format: {path.name}")


def _read_cv_tsv(
    archive: Path, language: str, max_texts: int, seed: int,
    min_utterance_chars: int = 1, max_utterance_chars: int | None = None,
    min_duration_s: float = 0.0, max_duration_s: float | None = None,
) -> list[Utterance]:
    """Read the Common Voice validated bucket without arbitrary text/duration filters."""
    preferred=("validated.tsv","train.tsv","dev.tsv","test.tsv")
    rng=np.random.default_rng(stable_seed(language,"cv_text",base=seed))
    with _open_cv_archive(archive) as tar:
        members=[m for m in tar.getmembers() if m.isfile() and Path(m.name).name in preferred]
        if not members: raise RuntimeError(f"No Common Voice TSV metadata found in {archive.name}.")
        chosen=next((m for m in members if Path(m.name).name=="validated.tsv"),members[0])
        fh=tar.extractfile(chosen)
        if fh is None: raise RuntimeError(f"Could not read {chosen.name}.")
        rows=csv.DictReader((line.decode("utf-8",errors="replace") for line in fh),delimiter="\t")
        samples=[]; seen=0
        for row in rows:
            sentence=normalize_text(row.get("sentence",""))
            clip=row.get("path") or row.get("clip") or ""
            clip_key=Path(clip).name if clip else ""
            if not sentence or not clip_key: continue
            duration=_float_or_none(row.get("duration"))
            u=Utterance(language,sentence,duration,"common_voice",row.get("client_id") or None,clip_key)
            seen=reservoir_append(samples,u,seen,max_texts,rng)
        rng.shuffle(samples)
        return samples


def _mp3_duration(data: bytes) -> float | None:
    try:
        from mutagen.mp3 import MP3
        return float(MP3(io.BytesIO(data)).info.length)
    except Exception:
        return None


def _collect_cv_speech_durations(
    archive: Path, selected: list[Utterance], min_duration_s: float = 0.0, max_duration_s: float | None = None
) -> list[Utterance]:
    """Recover durations; retain every selected clip with positive finite duration."""
    def valid(x): return x is not None and np.isfinite(x) and x > 0
    result=[]; missing=[]
    for u in selected:
        if valid(u.duration_s): result.append(u)
        else: missing.append(u)
    if missing:
        with tarfile.open(archive,"r:gz" if archive.name.lower().endswith((".tar.gz",".tgz")) else "r:") as tar:
            need={u.clip_path:u for u in missing if u.clip_path}
            for member in tar:
                if not need or not member.isfile() or Path(member.name).suffix.lower() != ".mp3": continue
                key=Path(member.name).name; u=need.get(key)
                if u is None: continue
                fh=tar.extractfile(member)
                if fh is None: continue
                duration=_mp3_duration(fh.read())
                if valid(duration):
                    result.append(Utterance(u.language,u.text,float(duration),u.source,u.speaker,u.clip_path)); del need[key]
    by={u.clip_path:u for u in result if u.clip_path}
    return [by[u.clip_path] for u in selected if u.clip_path in by]


def load_common_voice_samples(
    language: str, data_dir: Path, max_texts: int, max_speech: int, seed: int,
    min_utterance_chars: int = 1, max_utterance_chars: int | None = None,
    min_duration_s: float = 0.0, max_duration_s: float | None = None,
) -> tuple[list[Utterance], list[Utterance], dict]:
    """Use one canonical population from validated.tsv for text and speech."""
    archive=download_common_voice(language,data_dir)
    target_n=min(int(max_texts),int(max_speech))
    if target_n<=0: raise ValueError("max_texts and max_speech must both be positive.")
    selected=_read_cv_tsv(archive,language,target_n,seed,min_utterance_chars,max_utterance_chars,min_duration_s,max_duration_s)
    canonical=_collect_cv_speech_durations(archive,selected,min_duration_s,max_duration_s)
    missing=len(selected)-len(canonical)
    min_required=max(100,min(target_n,1000))
    if len(canonical)<min_required:
        raise RuntimeError(f"Common Voice {language} yielded only {len(canonical)} usable validated clips; {missing} selected clips lacked a positive recoverable duration; at least {min_required} are required.")
    return canonical,list(canonical),{
        "archive":str(archive),"n_text":len(canonical),"n_speech":len(canonical),
        "canonical_n":len(canonical),"canonical_same_population":True,
        "validated_bucket_only":True,"missing_or_invalid_duration_after_selection":missing,
        "source":"Common Voice Scripted Speech 26.0"
    }

