from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# Run from Code/; src is a sibling directory.
PROJECT_ROOT = Path(__file__).resolve()
if PROJECT_ROOT.name == "src":
    PROJECT_ROOT = PROJECT_ROOT.parent
SRC = PROJECT_ROOT / "src"
sys.path.insert(0, str(SRC))

from config import load_settings
from corpora import load_common_voice_samples
from normalization import normalize_text
from speech_features import aggregate_speech_features
from locality import train_char_lm, evaluate_windowed_surprisal
from decay import fit_decay, bootstrap_lambda
from utils import choose_device, stable_seed


DEFAULT_SPLIT_SEEDS = [101, 202, 303, 404, 505]
DEFAULT_MODEL_SEEDS = [13, 29, 41, 53, 67]


def split_utterances(utterances: list[str], split_seed: int, train_fraction: float = 0.80):
    """
    Fixed utterance-level 80/20 split.

    This is deliberately the same split principle used by the current locality
    estimator: the unit of splitting is the Common Voice utterance, so context
    can never leak across an utterance boundary.
    """
    usable = [u for u in utterances if len(u) >= 2]
    if len(usable) < 2:
        raise ValueError("Need at least two usable utterances.")

    rng = np.random.default_rng(split_seed)
    order = rng.permutation(len(usable))
    shuffled = [usable[int(i)] for i in order]

    n_train = int(round(train_fraction * len(shuffled)))
    n_train = min(max(1, n_train), len(shuffled) - 1)
    return shuffled[:n_train], shuffled[n_train:]


def take_until(texts: list[str], char_cap: int) -> list[str]:
    out, total = [], 0
    for t in texts:
        n = len(t)
        if out and total + n > char_cap:
            break
        out.append(t)
        total += n
    return out


def run(config_path: Path, device: str = "auto",
        split_seeds: list[int] | None = None,
        model_seeds: list[int] | None = None):
    settings = load_settings(config_path, "full")
    language = "Korean"
    lang_code = "ko"

    if language not in settings.languages:
        raise ValueError(
            f"{config_path} does not contain Korean. "
            "Use additionals/config_korean_test.yaml."
        )

    split_seeds = split_seeds or DEFAULT_SPLIT_SEEDS
    model_seeds = model_seeds or DEFAULT_MODEL_SEEDS

    device_used = choose_device(device)
    sampling = settings.sampling()

    max_texts = int(sampling["max_text_samples_per_language"])
    max_speech = int(sampling["max_speech_segments_per_language_source"])
    char_budget = int(sampling["max_text_chars_per_language_source"])

    lp = dict(settings.raw["locality"])
    max_lag = int(lp.get("max_lag_chars", 32))

    # Match the current main analysis hyperparameters exactly.
    train_char_cap = int(lp.get("train_chars", 5_000_000))
    valid_char_cap = int(lp.get("valid_chars", 1_000_000))
    batch_size = int(lp.get("batch_size", 256))
    eval_positions = int(
        lp.get("eval_positions", lp.get("eval_batches", 200) * batch_size)
    )

    # Download/select the canonical Common Voice population ONCE.
    # All splits below reuse exactly the same normalized utterance population.
    cv_text, cv_speech, cv_meta = load_common_voice_samples(
        language=language,
        data_dir=settings.data_root / "common_voice",
        max_texts=max_texts,
        max_speech=max_speech,
        seed=int(sampling["seed"]),
    )

    normalized = []
    total_chars = 0
    for u in cv_text:
        t = normalize_text(u.text)
        if not t:
            continue
        n = len(t)
        if normalized and total_chars + n > char_budget:
            break
        normalized.append(t)
        total_chars += n

    if total_chars < int(sampling.get("min_text_characters", 45_000)):
        raise RuntimeError(
            f"Canonical Korean corpus has only {total_chars:,} normalized characters."
        )

    speech_feats = aggregate_speech_features(cv_speech, lang_code)
    spc = float(speech_feats["seconds_per_character"])

    params = dict(lp)
    params["train_chars"] = train_char_cap
    params["valid_chars"] = valid_char_cap
    params["batch_size"] = batch_size

    out_root = settings.results_root / "sensitivity"
    out_root.mkdir(parents=True, exist_ok=True)

    run_rows = []
    curve_rows = []
    split_rows = []

    print(f"Canonical Korean corpus: {len(normalized):,} utterances, {total_chars:,} chars")
    print(f"Seconds/character: {spc:.9f}")
    print(f"Device: {device_used}")
    print(f"Splits: {split_seeds}")
    print(f"Model seeds: {model_seeds}")
    print(f"Total model fits: {len(split_seeds) * len(model_seeds)}")

    for split_seed in split_seeds:
        train_texts, valid_texts = split_utterances(normalized, split_seed, 0.80)
        train_texts = take_until(train_texts, train_char_cap)
        valid_texts = take_until(valid_texts, valid_char_cap)

        train_chars = sum(map(len, train_texts))
        valid_chars = sum(map(len, valid_texts))

        if valid_chars < max_lag + 2:
            raise RuntimeError(
                f"Split {split_seed} has only {valid_chars} validation chars; "
                f"need > {max_lag + 1}."
            )

        split_curves = []

        for model_seed in model_seeds:
            model, vocab, stoi, _ = train_char_lm(
                train_texts,
                valid_texts,
                max_lag,
                device_used,
                params,
                language,
                int(model_seed),
            )
            model._stoi_for_eval = stoi

            # Fixed evaluation positions within a split. This isolates model
            # initialization variability from evaluation-subsample variability.
            eval_seed = stable_seed(
                language, "sensitivity_eval", int(split_seed), base=20260815
            )

            S = np.asarray(
                evaluate_windowed_surprisal(
                    model,
                    valid_texts,
                    max_lag=max_lag,
                    device=device_used,
                    batch_size=batch_size,
                    seed=eval_seed,
                    max_positions=eval_positions,
                ),
                dtype=float,
            )

            I = np.asarray(
                [S[t - 1] - S[t] for t in range(1, max_lag + 1)],
                dtype=float,
            )
            lags = np.arange(1, max_lag + 1, dtype=float)

            decay = fit_decay(lags, I, spc)
            decay.update(
                bootstrap_lambda(
                    lags,
                    I,
                    spc,
                    reps=int(lp.get("bootstrap_reps", 200)),
                    seed=stable_seed(
                        language,
                        "sensitivity_bootstrap",
                        int(split_seed),
                        int(model_seed),
                        base=20260815,
                    ),
                )
            )

            run_rows.append({
                "language": language,
                "split_seed": split_seed,
                "model_seed": model_seed,
                "train_utterances": len(train_texts),
                "valid_utterances": len(valid_texts),
                "train_characters": train_chars,
                "valid_characters": valid_chars,
                **decay,
            })

            for lag, s_val, i_val in zip(lags.astype(int), S[1:], I):
                curve_rows.append({
                    "language": language,
                    "split_seed": split_seed,
                    "model_seed": model_seed,
                    "lag_characters": int(lag),
                    "lag_seconds": float(lag * spc),
                    "S_t_bits": float(s_val),
                    "I_t_bits": float(i_val),
                })

            split_curves.append(I)

        # Model-initialization average within each fixed split.
        mean_I = np.mean(np.stack(split_curves, axis=0), axis=0)
        split_decay = fit_decay(lags, mean_I, spc)
        split_decay.update(
            bootstrap_lambda(
                lags,
                mean_I,
                spc,
                reps=int(lp.get("bootstrap_reps", 200)),
                seed=stable_seed(
                    language,
                    "split_curve_bootstrap",
                    int(split_seed),
                    base=20260815,
                ),
            )
        )

        split_rows.append({
            "language": language,
            "split_seed": split_seed,
            "train_utterances": len(train_texts),
            "valid_utterances": len(valid_texts),
            "train_characters": train_chars,
            "valid_characters": valid_chars,
            "n_model_seeds": len(model_seeds),
            **split_decay,
        })

    runs = pd.DataFrame(run_rows)
    curves = pd.DataFrame(curve_rows)
    splits = pd.DataFrame(split_rows)

    runs.to_csv(out_root / "sensitivity_model_runs.csv", index=False)
    curves.to_csv(out_root / "sensitivity_model_curves.csv", index=False)
    splits.to_csv(out_root / "sensitivity_split_summary.csv", index=False)

    # Pre-specified summary of the five independent split-level estimates.
    lam = splits["locality_lambda_per_s"].dropna().to_numpy()
    summary = {
        "language": language,
        "canonical_utterances": len(normalized),
        "canonical_characters": total_chars,
        "seconds_per_character": spc,
        "n_split_seeds": len(split_seeds),
        "n_model_seeds_per_split": len(model_seeds),
        "total_model_fits": len(split_seeds) * len(model_seeds),
        "lambda_per_s_median_across_splits": float(np.median(lam)) if len(lam) else np.nan,
        "lambda_per_s_mean_across_splits": float(np.mean(lam)) if len(lam) else np.nan,
        "lambda_per_s_sd_across_splits": float(np.std(lam, ddof=1)) if len(lam) > 1 else np.nan,
        "lambda_per_s_q025_across_splits": float(np.quantile(lam, 0.025)) if len(lam) else np.nan,
        "lambda_per_s_q975_across_splits": float(np.quantile(lam, 0.975)) if len(lam) else np.nan,
    }
    pd.DataFrame([summary]).to_csv(
        out_root / "sensitivity_overall_summary.csv", index=False
    )

    print("\nSensitivity analysis complete.")
    print(f"Outputs: {out_root}")
    print(splits[
        ["split_seed", "locality_lambda_per_s", "locality_lambda_r2",
         "locality_fit_rmse_bits", "hilberg_alpha", "hilberg_r2"]
    ].to_string(index=False))
    print("\nOverall split-level lambda summary:")
    for k, v in summary.items():
        if k.startswith("lambda_per_s_"):
            print(f"  {k}: {v}")


def main():
    parser = argparse.ArgumentParser(
        description="Korean locality estimator sensitivity analysis."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("additionals/config_korean_test.yaml"),
    )
    parser.add_argument("--device", default="auto")
    parser.add_argument(
        "--split-seeds",
        nargs="+",
        type=int,
        default=DEFAULT_SPLIT_SEEDS,
    )
    parser.add_argument(
        "--model-seeds",
        nargs="+",
        type=int,
        default=DEFAULT_MODEL_SEEDS,
    )
    args = parser.parse_args()

    run(
        config_path=args.config,
        device=args.device,
        split_seeds=args.split_seeds,
        model_seeds=args.model_seeds,
    )


if __name__ == "__main__":
    main()