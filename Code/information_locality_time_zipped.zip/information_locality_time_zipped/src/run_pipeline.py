from __future__ import annotations

import argparse
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(SRC_ROOT))

from pipeline import run  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the information-locality/time pipeline.")
    parser.add_argument("--mode", choices=["pilot", "full"], default="pilot")
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--config", default="additionals/config.yaml")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    run(
        config_path=Path(args.config),
        mode=args.mode,
        device=args.device,
        overwrite=args.overwrite,
    )


if __name__ == "__main__":
    main()
