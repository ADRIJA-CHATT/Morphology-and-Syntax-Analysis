from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / "additionals" / ".env")

# EXACT general Common Voice Scripted Speech 26.0 datasets requested.
# These are NOT accent/gender/region-specific subsets.
COMMON_VOICE_26: dict[str, dict[str, str]] = {
    "English": {"id": "cmqim2hn800ssnr07gvmpcnwu", "locale": "en", "title": "Common Voice Scripted Speech 26.0 - English"},
    "German": {"id": "cmqim3xpi00t6nr07k0myqtkr", "locale": "de", "title": "Common Voice Scripted Speech 26.0 - German"},
    "Dutch": {"id": "cmqinokkq00wwnr07hv5oax8l", "locale": "nl", "title": "Common Voice Scripted Speech 26.0 - Dutch"},
    "Swedish": {"id": "cmqintw0q00xwnr07mjjzpe61", "locale": "sv-SE", "title": "Common Voice Scripted Speech 26.0 - Swedish"},
    "French": {"id": "cmqim41b000tanr07q9btypkc", "locale": "fr", "title": "Common Voice Scripted Speech 26.0 - French"},
    "Spanish": {"id": "cmqim2spa00synr071fcp7av0", "locale": "es", "title": "Common Voice Scripted Speech 26.0 - Spanish"},
    "Italian": {"id": "cmqini14100vmnq07309ocknr", "locale": "it", "title": "Common Voice Scripted Speech 26.0 - Italian"},
    "Portuguese": {"id": "cmqinmnkf00w8nr07hkbbxgw7", "locale": "pt", "title": "Common Voice Scripted Speech 26.0 - Portuguese"},
    "Russian": {"id": "cmqinj9g500vsnr07qf4hmr3j", "locale": "ru", "title": "Common Voice Scripted Speech 26.0 - Russian"},
    "Polish": {"id": "cmqinmu2a00winq07gyrtri0q", "locale": "pl", "title": "Common Voice Scripted Speech 26.0 - Polish"},
    "Czech": {"id": "cmqinmdik00wanq07o6cqnhps", "locale": "cs", "title": "Common Voice Scripted Speech 26.0 - Czech"},
    "Turkish": {"id": "cmqinosfq00x4nr07gnk0rdf9", "locale": "tr", "title": "Common Voice Scripted Speech 26.0 - Turkish"},
    "Finnish": {"id": "cmqiodpav00yknq07kfcyu7c0", "locale": "fi", "title": "Common Voice Scripted Speech 26.0 - Finnish"},
    "Hungarian": {"id": "cmqinob6900wknr07s6fgcprx", "locale": "hu", "title": "Common Voice Scripted Speech 26.0 - Hungarian"},
    "Indonesian": {"id": "cmqinqwef00xonr07z4vbfovw", "locale": "id", "title": "Common Voice Scripted Speech 26.0 - Indonesian"},
    "Vietnamese": {"id": "cmqiof4sv00ywnq07m63v4pnp", "locale": "vi", "title": "Common Voice Scripted Speech 26.0 - Vietnamese"},
    "Hindi": {"id": "cmqiod71900zgnr07uiyw57br", "locale": "hi", "title": "Common Voice Scripted Speech 26.0 - Hindi"},
    "Mandarin Chinese": {"id": "cmqim47x700tunq074za20dq1", "locale": "zh-CN", "title": "Common Voice Scripted Speech 26.0 - Chinese (China)"},
    "Japanese": {"id": "cmqim4lxy00tunr07cjkcupeg", "locale": "ja", "title": "Common Voice Scripted Speech 26.0 - Japanese"},
    "Korean": {"id": "cmqi922c5001pnq07dmj0oypw", "locale": "ko", "title": "Common Voice Scripted Speech 26.0 - Korean"},
}


def _attr(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if hasattr(obj, name):
        return getattr(obj, name)
    try:
        return obj.get(name, default)
    except Exception:
        return default


def get_common_voice_details(language: str):
    if language not in COMMON_VOICE_26:
        raise KeyError(f"No verified Common Voice v26 dataset for {language}.")
    try:
        from datacollective import get_dataset_details
    except ImportError as exc:
        raise RuntimeError(
            "datacollective is not installed. Install requirements.txt in the active venv."
        ) from exc

    details = get_dataset_details(COMMON_VOICE_26[language]["id"])
    expected = COMMON_VOICE_26[language]
    actual_title = str(_attr(details, "name", ""))
    actual_locale = str(_attr(details, "locale", ""))
    actual_task = str(_attr(details, "task", "")).upper()

    if actual_title != expected["title"]:
        raise RuntimeError(
            f"Common Voice safety check failed for {language}: expected exact dataset "
            f"'{expected['title']}', got '{actual_title}'."
        )
    if actual_locale != expected["locale"]:
        raise RuntimeError(
            f"Common Voice safety check failed for {language}: expected locale "
            f"'{expected['locale']}', got '{actual_locale}'."
        )
    if actual_task != "ASR":
        raise RuntimeError(
            f"Common Voice safety check failed for {language}: expected ASR, got '{actual_task}'."
        )
    return details


def download_common_voice(language: str, out_dir: Path) -> Path:
    """
    Download exactly one requested general Common Voice v26 archive.
    MDC itself handles resumable .part/.checksum downloads.
    """
    details = get_common_voice_details(language)
    dataset_id = COMMON_VOICE_26[language]["id"]
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        from datacollective import download_dataset
        archive = download_dataset(
            dataset_id,
            download_directory=str(out_dir),
            show_progress=True,
            overwrite_existing=False,
            enable_logging=False,
        )
        return Path(archive)
    except PermissionError as exc:
        raise RuntimeError(
            f"MDC access is not enabled for {language}. "
            f"Open https://mozilladatacollective.com/datasets/{dataset_id}, "
            "read/accept the dataset-specific terms, then rerun. "
            "No manual file download is required."
        ) from exc
    except Exception as exc:
        # MDC currently reports terms/access failures in a few SDK exception paths
        # with RuntimeError/HTTPError instead of PermissionError.
        msg = str(exc)
        if any(x in msg.lower() for x in (
            "terms", "conditions", "access denied", "forbidden", "403"
        )):
            raise RuntimeError(
                f"MDC access is not enabled for {language}. "
                f"Open https://mozilladatacollective.com/datasets/{dataset_id}, "
                "read/accept the dataset-specific terms, then rerun. "
                "No manual file download is required."
            ) from exc
        raise


def hf_download_exact(
    repo_id: str,
    filename: str,
    revision: str = "main",
    cache_dir: Optional[str] = None,
) -> Path:
    from huggingface_hub import hf_hub_download

    cache = cache_dir or os.getenv("HF_DATASETS_CACHE") or os.getenv("HF_HOME")
    try:
        return Path(
            hf_hub_download(
                repo_id=repo_id,
                filename=filename,
                repo_type="dataset",
                revision=revision,
                cache_dir=cache,
            )
        )
    except Exception as exc:
        raise RuntimeError(
            f"Could not download Hugging Face dataset file "
            f"'{repo_id}/{filename}' at revision '{revision}'."
        ) from exc