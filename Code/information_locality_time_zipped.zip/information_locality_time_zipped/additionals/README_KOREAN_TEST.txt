KOREAN-ONLY TEST — CLEAN PATCH

Do not replace the main corpus/statistical modules.

Replace ONLY:
    src/pipeline.py

Add ONLY:
    additionals/config_korean_test.yaml

Leave unchanged:
    src/corpora.py
    src/downloaders.py
    src/morphology.py
    src/decay.py
    src/config.py
    run_pipeline.py
    additionals/config.yaml
    requirements.txt
    .env

The pipeline.py change is only the directory-creation ordering fix:
the data/results directories are created before shutil.disk_usage() is called.

Test:
    python -m py_compile src/pipeline.py
    python src/run_pipeline.py --config additionals/config_korean_test.yaml --mode full --overwrite

Outputs are isolated in:
    data_korean_test/
    results_korean_test/

After the Korean test passes, restore the original src/pipeline.py if desired
and run the unchanged main additionals/config.yaml for the 20-language experiment.

PRIMARY LOCALITY ESTIMATOR
The primary information-locality estimator is a held-out character-level
interpolated Kneser-Ney n-gram estimator. Context orders 1..T+1 are evaluated
on held-out utterances, and S_t is made non-increasing via min_{s<=t} S_s before
computing I_t = S_t - S_{t+1}. The previous neural character LM is retained in
src/locality.py as a secondary robustness implementation and is not the primary
paper estimate.


Locality lag rule: corpora below 100,000 canonical characters use max_lag_chars=10; corpora at or above 100,000 use 20. This rule is fixed by corpus size before examining I_t.


PRIMARY LOCALITY ESTIMATOR (publication baseline)
-------------------------------------------------
For each language, fit separate held-out character n-gram Kneser-Ney models of
orders 1..T+1 on utterance-level training data and evaluate every order on the
same held-out target positions. Apply the Hahn-Degen-Futrell monotone correction
S_hat_t = min_{s<=t} S_s, then I_t = S_hat_t - S_hat_{t+1}.

The low-resource rule is fixed before inspecting locality curves:
<100,000 canonical characters -> T=10; >=100,000 -> T=20.
No fitted-value-based lag selection is permitted.

The neural character LM remains available only as a secondary robustness method.
